import sys
from PyQt6.QtWidgets import (
    QApplication, QWidget, QPushButton, QLabel, QVBoxLayout, QHBoxLayout, QLineEdit
)
from PyQt6.QtCore import QTimer
import can
import struct

GEAR_RATIO = 17.0  # 1:17 gearbox
DEVICE_ID = 1      # CAN device ID

# Initialise CAN exactly as requested
bus = can.interface.Bus(interface="socketcan", channel="can0", bitrate=500000)
notifier = can.Notifier(bus, [])

class ServoGUI(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Servo42D GUI Control")
        self.setGeometry(100, 100, 300, 200)

        # Widgets
        self.position_input = QLineEdit()
        self.position_input.setPlaceholderText("Enter desired output angle (deg)")

        self.send_button = QPushButton("Send Angle")
        self.send_button.clicked.connect(self.send_position)

        self.encoder_label = QLabel("Encoder Angle: --")

        # Layout
        layout = QVBoxLayout()
        layout.addWidget(self.position_input)
        layout.addWidget(self.send_button)
        layout.addWidget(self.encoder_label)

        self.setLayout(layout)

        # Polling Timer for CAN feedback
        self.timer = QTimer()
        self.timer.timeout.connect(self.read_encoder)
        self.timer.start(100)

    def send_position(self):
        try:
            desired_output_angle = float(self.position_input.text())
            internal_angle = desired_output_angle * GEAR_RATIO

            # Convert angle to fixed-point format (0.01 deg/LSB)
            angle_value = int(internal_angle * 100)

            # Pack into little-endian 4-byte int
            data = struct.pack("<i", angle_value)

            msg = can.Message(
                arbitration_id=DEVICE_ID,
                data=data,
                is_extended_id=False
            )

            bus.send(msg)

        except Exception as e:
            self.encoder_label.setText(f"Send Error: {e}")

    def read_encoder(self):
        msg = bus.recv(timeout=0.01)
        if msg and msg.arbitration_id == DEVICE_ID:
            try:
                raw_angle, = struct.unpack("<i", msg.data[:4])
                output_angle = raw_angle / 100.0 / GEAR_RATIO
                self.encoder_label.setText(f"Encoder Angle: {output_angle:.2f}°")
            except Exception as e:
                self.encoder_label.setText(f"Read Error: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ServoGUI()
    window.show()
    sys.exit(app.exec())
