import tkinter as tk
from tkinter import ttk, messagebox
import can
from mks_servo_can import MksServo 
from enum import Enum 
import threading
import time
import traceback

# Attempt to import specific enums, with fallbacks
try:
    from mks_servo_can.mks_enums import Enable as MksEnableEnum
    from mks_servo_can.mks_enums import Direction as MksDirectionEnum
    from mks_servo_can.mks_enums import SuccessStatus
    from mks_servo_can.mks_enums import GoHomeResult # For homing result checking
    print("DEBUG: Successfully imported Enums from mks_servo_can.mks_enums")
except ImportError:
    try: 
        from mks_servo_can import Enable as MksEnableEnum
        from mks_servo_can import Direction as MksDirectionEnum
        from mks_servo_can import SuccessStatus
        from mks_servo_can import GoHomeResult
        print("DEBUG: Successfully imported Enums directly from mks_servo_can")
    except ImportError:
        print("DEBUG: Failed to import specific Enums. Using placeholder Enums.")
        class MksEnableEnum(Enum): Disable = 0; Enable = 1
        class MksDirectionEnum(Enum): CW = 0; CCW = 1 
        class SuccessStatus(Enum): Fail = 0; Success = 1
        class GoHomeResult(Enum): Fail = 0; Start = 1; Success = 2 # Based on manual for CAN CMD 91H

# --- Configuration ---
CAN_INTERFACE = "socketcan"
CAN_CHANNEL = "can0"
CAN_BITRATE = 500000
SERVO_CAN_ID = 1
GEAR_RATIO = 17.0 

# PULSES_PER_MOTOR_REVOLUTION_FOR_COMMAND defines the number of pulses the servo controller
# expects for one full motor revolution when using pulse-based commands (like run_motor_absolute_motion_by_axis).
# From MKS Manual for commands like 0xFD and 0xF5, 0x4000 (16384) corresponds to one revolution.
PULSES_PER_MOTOR_REVOLUTION_FOR_COMMAND = 16384 

print(f"COMMANDS will use {PULSES_PER_MOTOR_REVOLUTION_FOR_COMMAND} pulses per motor revolution for 'abs_axis'.")
print("FEEDBACK from 'read_encoder_value_addition()' scaling DEPENDS ON SUBDIVISION.")
print("Subdivision 0 is assumed to make feedback units = motor cdeg.")
print("Other subdivisions use CALIBRATION_FEEDBACK_MAP based on your logger script results.")

# --- Global Variables ---
bus = None
notifier = None
servo_wrapper = None
current_output_angle_deg = 0.0 
stop_reading_thread = False
gui_ready = False 
app_running = True
e_stop_active = False
library_feedback_raw_offset_at_zero = 0 

FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT = 100.0 # Default for subdivision 0

# CALIBRATION_FEEDBACK_MAP: Stores {subdivision_code: feedback_units_from_read_encoder_value_addition_per_motor_degree}
# Updated with your logger script results.
CALIBRATION_FEEDBACK_MAP = {
    0:   100.0,                 # Subdivision 0: 100 cdeg per motor degree
    1:   15941.0 / 360.0,       # Approx 44.2806
    2:   16231.0 / 360.0,       # Approx 45.0861
    4:   16401.0 / 360.0,       # Approx 45.5583
    8:   16378.0 / 360.0,       # Approx 45.4944
    16:  16378.0 / 360.0,       # Approx 45.4944
    32:  16378.0 / 360.0,       # Approx 45.4944
    64:  16377.0 / 360.0,       # Approx 45.4917
    128: 16383.0 / 360.0,       # Approx 45.5083
    255: 16321.0 / 360.0,       # Approx 45.3361
}

current_speed_tkvar = None
current_acceleration_tkvar = None
current_subdivision_tkvar = None
current_interpolation_enabled_tkvar = None
current_feedback_scaling_display_tkvar = None 

# These are the integer codes sent to servo_wrapper.set_subdivisions()
# Based on your logger script successfully using these direct integer values.
SUBDIVISION_CODES_FOR_GUI = [0, 1, 2, 4, 8, 16, 32, 64, 128, 255] 
enable_val_for_interpolation_type = None # To store MksEnableEnum.Enable type or boolean True

def update_feedback_scaling_for_subdivision(subdivision_code_from_gui):
    global FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT, library_feedback_raw_offset_at_zero, gui_ready
    global current_feedback_scaling_display_tkvar 

    subdivision_value = int(subdivision_code_from_gui)

    if subdivision_value in CALIBRATION_FEEDBACK_MAP:
        FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT = CALIBRATION_FEEDBACK_MAP[subdivision_value]
        status_msg = f"Using calibrated FeedbackUnits/MotorDegree for subdivision code {subdivision_value}: {FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT:.4f}"
        if current_feedback_scaling_display_tkvar: current_feedback_scaling_display_tkvar.set(f"{FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT:.4f} units/deg")
    else:
        FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT = None 
        status_msg = f"WARNING: No Feedback scaling for subdivision code {subdivision_value}. Display will be Raw Units."
        if current_feedback_scaling_display_tkvar: current_feedback_scaling_display_tkvar.set("N/A (Uncalibrated)")
        if gui_ready:
            messagebox.showwarning("Calibration Needed",
                                   status_msg + "\nTo show degrees, run calibration script for this subdivision, then update CALIBRATION_FEEDBACK_MAP in this script.")
    print(status_msg)
    
    old_offset = library_feedback_raw_offset_at_zero
    library_feedback_raw_offset_at_zero = 0 
    print(f"Feedback offset reset from {old_offset} to 0 due to subdivision change to {subdivision_value}. Please 'Set Zero' or 'Home'.")
    if gui_ready :
         messagebox.showinfo("Re-Zero/Re-Home Recommended", 
                            f"Subdivision changed to code {subdivision_value}.\n"
                            "Display offset reset. Please press 'Set Zero' or 'Home Motor'.")

def set_servo_configuration_from_gui(): 
    global servo_wrapper, app_running, gui_ready
    global current_subdivision_tkvar, current_interpolation_enabled_tkvar, enable_val_for_interpolation_type

    if not (servo_wrapper and app_running):
        if gui_ready: messagebox.showwarning("Config Error", "Servo not connected.")
        else: print("Config Error: Servo not connected.")
        return
    if not all([current_subdivision_tkvar, current_interpolation_enabled_tkvar]):
        print("Error: Tkinter config variables not initialized for set_servo_configuration_from_gui.")
        if gui_ready: messagebox.showerror("Internal Error", "GUI config variables not ready.")
        return

    subdiv_code_val = current_subdivision_tkvar.get()
    interp_bool_val = current_interpolation_enabled_tkvar.get()
    
    interp_setting_for_servo = interp_bool_val 
    interp_setting_str = str(interp_bool_val)
    if isinstance(enable_val_for_interpolation_type, type(MksEnableEnum.Enable)):
        interp_setting_for_servo = MksEnableEnum.Enable if interp_bool_val else MksEnableEnum.Disable
        interp_setting_str = f"MksEnableEnum.{interp_setting_for_servo.name}" 
    else: 
        interp_setting_for_servo = interp_bool_val 
        interp_setting_str = str(interp_bool_val)

    print(f"Attempting to set servo subdivisions to code: {subdiv_code_val}...")
    try:
        result_subdiv = servo_wrapper.set_subdivisions(subdiv_code_val)
        print(f"  set_subdivisions({subdiv_code_val}) result: {result_subdiv}")
        
        print(f"Attempting to set subdivision interpolation to: {interp_setting_str}...")
        result_interp = servo_wrapper.set_subdivision_interpolation(interp_setting_for_servo) 
        print(f"  set_subdivision_interpolation({interp_setting_str}) result: {result_interp}")
        
        time.sleep(0.1) 
        update_feedback_scaling_for_subdivision(subdiv_code_val)
        
        print("Servo configuration updated from GUI.")
    except AttributeError as ae:
        print(f"  Error during servo config (AttributeError): {ae}.")
        if gui_ready: messagebox.showerror("Config Error", f"AttributeError: {ae}. MksServo library might be missing this function or enum.")
    except Exception as e_conf:
        print(f"  Error during servo configuration: {e_conf}")
        if gui_ready: messagebox.showerror("Config Error", f"Error: {e_conf}")

def _apply_default_servo_config():
    global servo_wrapper, current_subdivision_tkvar, current_interpolation_enabled_tkvar, gui_ready
    if not servo_wrapper: 
        print("Cannot apply default config, servo_wrapper is None.")
        return

    print("Applying default servo configuration (Subdivision Code 0, Interpolation On)...")
    try:
        if current_subdivision_tkvar: current_subdivision_tkvar.set(0)
        else: print("Warning: current_subdivision_tkvar not initialized for default config set.")
        
        if current_interpolation_enabled_tkvar: current_interpolation_enabled_tkvar.set(True)
        else: print("Warning: current_interpolation_enabled_tkvar not initialized for default config set.")
        
        if current_subdivision_tkvar and current_interpolation_enabled_tkvar : 
            set_servo_configuration_from_gui() 
        else: 
            print("Fallback: Applying default config directly as Tkinter vars were not ready.")
            servo_wrapper.set_subdivisions(0)
            interp_val_direct = MksEnableEnum.Enable if isinstance(enable_val_for_interpolation_type, type(MksEnableEnum.Enable)) else True
            servo_wrapper.set_subdivision_interpolation(interp_val_direct)
            update_feedback_scaling_for_subdivision(0) 

    except Exception as e:
        print(f"Error applying default servo config: {e}")
        if gui_ready: messagebox.showerror("Config Error", f"Failed to apply default servo config: {e}")

def connect_can():
    global bus, notifier, servo_wrapper, app_running, e_stop_active, library_feedback_raw_offset_at_zero
    global enable_val_for_interpolation_type 

    if not app_running: return False
    e_stop_active = False; library_feedback_raw_offset_at_zero = 0 
    print("Attempting connection...")
    try:
        bus = can.interface.Bus(interface=CAN_INTERFACE, channel=CAN_CHANNEL, bitrate=CAN_BITRATE)
        if bus is None: raise ConnectionError("CAN bus is None.")
        initial_listeners = [] 
        notifier = can.Notifier(bus, initial_listeners) 
        servo_wrapper = MksServo(bus, notifier, SERVO_CAN_ID) 

        if hasattr(servo_wrapper, 'can_id'): print(f"servo_wrapper.can_id: {servo_wrapper.can_id}")
        else: print("Warning: servo_wrapper no 'can_id' attribute.")
        print(f"Connected. Servo Node ID: {SERVO_CAN_ID}.")
        listener_names = [str(type(l).__name__) for l in notifier.listeners if notifier and notifier.listeners]
        print(f"Notifier listeners: {listener_names}") 
        
        if servo_wrapper:
            enable_enum = getattr(MksServo, 'Enable', None)
            if enable_enum and hasattr(enable_enum, 'Enable') and hasattr(enable_enum, 'Disable'):
                enable_val_for_interpolation_type = MksServo.Enable.Enable 
                print(f"  Using MksServo.Enable enum type for interpolation logic.")
            else:
                enable_val_for_interpolation_type = True 
                print(f"  MksServo.Enable enum not found or missing members, using boolean True/False for interpolation logic.")
            
            _apply_default_servo_config() # Applies subdiv 0, interp ON, and updates feedback scaling

            print("\n--- Initial read_encoder_value_addition() (post-config) ---")
            try:
                initial_feedback_val = servo_wrapper.read_encoder_value_addition() 
                print(f"  Initial call to read_encoder_value_addition() returned: {initial_feedback_val} (type: {type(initial_feedback_val)})")
                if isinstance(initial_feedback_val, int):
                    library_feedback_raw_offset_at_zero = initial_feedback_val 
                    print(f"  Initial library_feedback_raw_offset_at_zero set to: {library_feedback_raw_offset_at_zero} (in current feedback units).")
                elif initial_feedback_val is None: print("  Initial read returned None. Offset remains 0.")
                else: print(f"  WARNING: Initial read returned non-int: {type(initial_feedback_val)}.")
            except TypeError as te: 
                print(f"  CRITICAL LIBRARY TypeError from read_encoder_value_addition(): {te}")
                if gui_ready: messagebox.showerror("Library Error", f"Feedback method error: {te}. Check library version/installation.")
            except Exception as e:
                print(f"  Error calling read_encoder_value_addition() during connect: {e}")
                if gui_ready: messagebox.showerror("Library Error", f"Feedback method error: {e}")
        return True
    except Exception as e:
        error_msg = f"CAN connection error: {e}"; print(error_msg); traceback.print_exc()
        if gui_ready: messagebox.showerror("CAN Connection Error", f"{error_msg}\nCheck console.")
        bus, notifier, servo_wrapper = None, None, None
        return False

def disconnect_can():
    global bus, notifier, stop_reading_thread, servo_wrapper, reading_thread
    print("Disconnect_can called.")
    current_thread = threading.current_thread()
    if reading_thread and reading_thread.is_alive() and reading_thread != current_thread:
        print("Waiting for angle reading thread to stop...")
        reading_thread.join(timeout=2.0) 
        if reading_thread.is_alive(): print("Warning: Angle reading thread did not stop cleanly.")
        else: print("Angle reading thread stopped.")
    elif reading_thread == current_thread:
        print("Disconnect_can called from within reading_thread. Will not join self.")
    if notifier:
        try: notifier.stop(timeout=1.0); print("Notifier stopped.")
        except Exception as e: print(f"Error stopping notifier: {e}")
        notifier = None
    if bus:
        try: bus.shutdown(); print("CAN bus shutdown.")
        except Exception as e: print(f"Error shutting bus: {e}")
        bus = None
    servo_wrapper = None; print("CAN resources released.")

def set_output_angle_from_gui():
    global root, gui_ready, servo_wrapper, angle_entry, current_speed_tkvar, current_acceleration_tkvar 
    if not app_running :
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Error", "Application not running.")
        else: print("Error: Application not running for set_output_angle_from_gui")
        return
    if servo_wrapper is None:
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Error", "Servo not connected.")
        else: print("Error: Servo not connected for set_output_angle_from_gui")
        return
    try:
        angle_str = angle_entry.get()
        speed_val = current_speed_tkvar.get() 
        accel_val = current_acceleration_tkvar.get() 
        _set_output_angle_command(angle_str, speed_val, accel_val)
    except tk.TclError as e:
        msg = f"GUI Error getting parameters: {e}. Ensure values are set."
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("GUI Error", msg)
        else: print(msg)
    except ValueError: 
        msg = "Invalid number format in Angle/Speed/Accel entries."
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Input Error", msg)
        else: print(msg)

def _set_output_angle_command(target_output_angle_deg_str, speed, acceleration):
    """ Sends move command in ABSOLUTE RAW MOTOR PULSES (16384/rev system for commands) """
    global servo_wrapper, e_stop_active, gui_ready, root, library_feedback_raw_offset_at_zero

    if e_stop_active: 
        if gui_ready and root and root.winfo_exists(): messagebox.showwarning("E-STOP Active", "Motion blocked.")
        else: print("E-STOP Active, motion blocked.")
        return

    try:
        target_output_angle_deg = float(target_output_angle_deg_str)
        
        motor_degrees_relative_to_output_zero = target_output_angle_deg * GEAR_RATIO
        pulses_for_relative_move_float = \
            (motor_degrees_relative_to_output_zero / 360.0) * PULSES_PER_MOTOR_REVOLUTION_FOR_COMMAND
        
        # The library_feedback_raw_offset_at_zero is the servo's absolute pulse reading (in its current feedback units)
        # when "Set Zero" was pressed.
        # However, set_current_axis_to_zero() makes the *servo's internal command reference* for absolute pulse moves become 0.
        # So, the target for run_motor_absolute_motion_by_axis should be relative to this new servo internal zero.
        # Therefore, we send the calculated relative pulses directly.
        motor_target_command_pulses = round(pulses_for_relative_move_float)

        target_speed = int(speed)
        target_acceleration = int(acceleration)

        max_s = MksServo.MAX_SPEED if hasattr(MksServo, 'MAX_SPEED') else 3000
        max_a = MksServo.MAX_ACCELERATION if hasattr(MksServo, 'MAX_ACCELERATION') else 255
        MOTOR_PULSE_CMD_MIN = -(1 << 23); MOTOR_PULSE_CMD_MAX = (1 << 23) - 1 

        valid_input = True; error_messages = []
        if not (0 < target_speed <= max_s): error_messages.append(f"Speed {target_speed} RPM out of range (1-{max_s})."); valid_input = False
        if not (0 < target_acceleration <= max_a): error_messages.append(f"Accel {target_acceleration} out of range (1-{max_a})."); valid_input = False
        # The command is now relative to the servo's internal zero after set_current_axis_to_zero
        if not (MOTOR_PULSE_CMD_MIN <= motor_target_command_pulses <= MOTOR_PULSE_CMD_MAX): 
            error_messages.append(f"Target motor command pulses ({motor_target_command_pulses}) exceeds servo's 24-bit command range."); valid_input = False
        
        if not valid_input:
            full_error_msg = "\n".join(error_messages)
            if gui_ready and root and root.winfo_exists(): messagebox.showerror("Input Error(s)", full_error_msg)
            else: print(f"Input Error(s):\n{full_error_msg}")
            return
        
        print(f"Requesting output: {target_output_angle_deg:.2f}°\n"
              f"  Target motor degrees (relative to logical zero): {motor_degrees_relative_to_output_zero:.3f}°\n"
              f"  Command Pulses to Servo (relative to its internal zero): {motor_target_command_pulses}\n"
              f"  Params: speed={target_speed}, accel={target_acceleration}")
        
        servo_wrapper.run_motor_absolute_motion_by_axis(target_speed, target_acceleration, motor_target_command_pulses)
        print(f"Command 'run_motor_absolute_motion_by_axis' sent with target {motor_target_command_pulses} (servo-relative pulses).")

    except ValueError: 
        msg = "Invalid number format for angle, speed, or acceleration."
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Input Error", msg)
        else: print(f"Input Error: {msg}")
    except Exception as e: 
        msg = f"Error sending move command: {e}"
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Servo Command Error", msg)
        else: print(f"Servo Command Error: {msg}")
        traceback.print_exc()

def read_current_angle_periodically():
    global current_output_angle_deg, servo_wrapper, stop_reading_thread, app_running, gui_ready, e_stop_active
    global library_feedback_raw_offset_at_zero, FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT

    print("Angle reading thread started (Using library feedback, subdivision aware).")
    loop_count, log_interval = 0, 20 
    query_frequency = 1 

    while not stop_reading_thread and app_running:
        if gui_ready and root and root.winfo_exists():
            loop_count += 1
            calculated_out_angle = None 
            raw_lib_val = None
            is_calibrated_this_cycle = False

            if servo_wrapper and not e_stop_active and loop_count % query_frequency == 0:
                try:
                    raw_lib_val = servo_wrapper.read_encoder_value_addition() 
                    if raw_lib_val is not None:
                        if isinstance(raw_lib_val, int):
                            # This is the raw value from the library. Its offset was captured at zeroing.
                            relative_feedback_units = raw_lib_val - library_feedback_raw_offset_at_zero
                            
                            if FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT is not None and FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT != 0:
                                motor_angle_deg = relative_feedback_units / FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT
                                if GEAR_RATIO != 0: calculated_out_angle = motor_angle_deg / GEAR_RATIO
                                else: calculated_out_angle = 0.0 # Should not happen
                                is_calibrated_this_cycle = True
                            else: # PPMD is None (uncalibrated for current subdivision)
                                calculated_out_angle = relative_feedback_units # Store raw relative units if not calibrated
                                is_calibrated_this_cycle = False
                            
                            if calculated_out_angle is not None and is_calibrated_this_cycle:
                                current_output_angle_deg = calculated_out_angle # Update global only if degrees
                        else: 
                            if loop_count % log_interval == 0: print(f"Warning: Feedback non-integer: {raw_lib_val} (type: {type(raw_lib_val)})")
                except TypeError as te: 
                    if loop_count % (log_interval * 2) == 0: print(f"CRITICAL Reader: TypeError from read_encoder_value_addition(): {te}.")
                    # This implies library is broken or servo not responding correctly
                except Exception as e: 
                    if loop_count % log_interval == 0: print(f"Error in reader query: {e}")
            
            # Logging
            log_output_angle_str = 'N/A'
            if raw_lib_val is not None: # Ensure raw_lib_val was read in this cycle
                current_relative_units = raw_lib_val - library_feedback_raw_offset_at_zero
                if is_calibrated_this_cycle and calculated_out_angle is not None: 
                    log_output_angle_str = f"{calculated_out_angle:.3f}°"
                else: # Uncalibrated, show raw relative units
                    log_output_angle_str = f"RawRel: {current_relative_units}" 
            
            if loop_count % log_interval == 0: 
                ppmd_str = f"{FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT:.4f}" if FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT is not None else 'N/A (Uncalibrated)'
                print(f"AngleCalc (L{loop_count}): RawLibVal={raw_lib_val}, LibOffset={library_feedback_raw_offset_at_zero}, FeedbackUnitsPerMotorDeg={ppmd_str}, Output={log_output_angle_str}")

            # GUI Update
            if raw_lib_val is not None and app_running and root and root.winfo_exists():
                # Value to display is either calculated degrees or raw relative units
                display_value = calculated_out_angle if is_calibrated_this_cycle and calculated_out_angle is not None else (raw_lib_val - library_feedback_raw_offset_at_zero)
                try: root.after(0, update_angle_display, display_value, is_calibrated_this_cycle)
                except tk.TclError:
                    if app_running: print("AngleRead: root.after failed, window closing.")
                    break # Exit thread if GUI is gone
        else: 
            if stop_reading_thread or not app_running: break
            time.sleep(0.1) # Wait if GUI not ready or thread stopping
        time.sleep(0.1) 
    print("Angle reading thread stopped.")

def on_set_zero_button():
    global servo_wrapper, current_output_angle_deg, app_running, root, e_stop_active
    global library_feedback_raw_offset_at_zero, FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT 

    if e_stop_active: 
        if app_running and root and root.winfo_exists(): messagebox.showwarning("E-STOP Active", "Cannot set zero.")
        else: print("E-STOP Active, cannot set zero.")
        return
    if servo_wrapper is None: 
        if app_running and root and root.winfo_exists(): messagebox.showerror("Error", "Servo not connected.")
        else: print("Error: Servo not connected for Set Zero.")
        return
    
    print("Attempting to set current position as zero...")
    try:
        # This command tells the servo that its current physical position is its new '0'
        # for subsequent absolute pulse commands.
        servo_wrapper.set_current_axis_to_zero() 
        print("Command 'set_current_axis_to_zero' sent to servo controller.")
        time.sleep(0.2) # Give servo a moment 
        
        # After set_current_axis_to_zero, read_encoder_value_addition() should report the
        # servo's absolute position value at this new physical zero.
        # Your logs showed this becomes 0 for subdivision 0.
        current_feedback_at_zero = None
        try:
            current_feedback_at_zero = servo_wrapper.read_encoder_value_addition()
            print(f"  Value read from servo after zeroing command: {current_feedback_at_zero}")
        except TypeError as te:
            print(f"CRITICAL SetZero: TypeError calling read_encoder_value_addition(): {te}. Cannot update offset.")
            if app_running and root and root.winfo_exists(): messagebox.showerror("Library Error", f"Cannot capture zero offset: {te}")
            return 
        except Exception as e_capture:
            print(f"SetZero: Error capturing offset value: {e_capture}")
            current_feedback_at_zero = None 

        if current_feedback_at_zero is not None and isinstance(current_feedback_at_zero, int):
            # This value IS the new zero reference for the library's feedback.
            # All subsequent relative calculations will be (current_reading - this_value).
            library_feedback_raw_offset_at_zero = current_feedback_at_zero 
            print(f"New display zero offset captured: {library_feedback_raw_offset_at_zero} (in current feedback units)")
        else:
            print(f"Warning: Could not get valid value from library for new zero offset (got: {current_feedback_at_zero}). Offset remains: {library_feedback_raw_offset_at_zero}")

        is_calibrated = FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT is not None
        # Display 0 degrees if calibrated, or 0 raw relative units if not.
        # The relative raw units are (current_feedback_at_zero - new_offset), which should be 0.
        display_value_after_zero = 0.0 
        
        if is_calibrated: current_output_angle_deg = 0.0

        if app_running and root and root.winfo_exists(): 
            update_angle_display(display_value_after_zero, is_calibrated) 
            messagebox.showinfo("Set Zero", "Motor internal zero reset. Display offset updated.")
        elif app_running: print("Set Zero: GUI not available for confirmation.")
    except Exception as e: 
        if app_running and root and root.winfo_exists(): messagebox.showerror("Servo Command Error", f"Error during 'set zero': {e}")
        else: print(f"Error during 'set zero' (GUI unavailable): {e}")
        traceback.print_exc()

def on_home_motor_button(): 
    global servo_wrapper, app_running, root, e_stop_active, library_feedback_raw_offset_at_zero, FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT, gui_ready
    global enable_val_for_interpolation_type 

    if e_stop_active: # ... (same checks)
        if gui_ready and root and root.winfo_exists(): messagebox.showwarning("E-STOP Active", "Cannot home motor.")
        else: print("E-STOP Active, cannot home motor.")
        return
    if servo_wrapper is None: # ... (same checks)
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Error", "Servo not connected.")
        else: print("Error: Servo not connected for Homing.")
        return

    print("Attempting to home motor using 'noLimit' (stall/hard-stop) method...")
    
    # --- Parameters for "noLimit" Homing (USER MUST VERIFY/ADJUST THESE from MKS Manual for CAN Commands 90H & 94H) ---
    homing_speed_rpm = 50 
    homing_direction_val = MksServo.Direction.CW if hasattr(MksServo, 'Direction') else 0 # 0=CW
    
    # For CAN CMD 90H (set_home parameters)
    # byte6: EndLimit (enable/disable endstop-limit function AFTER homing)
    endlimit_after_home_setting = MksEnableEnum.Disable # Default to MksEnableEnum.Disable
    if isinstance(enable_val_for_interpolation_type, type(MksEnableEnum.Enable)): # Check if the type is the enum
        endlimit_after_home_setting = MksEnableEnum.Disable
    else: # Fallback if it's boolean
        endlimit_after_home_setting = False
    
    # byte2: homeTrig (effective level of end stop) - For noLimit, this might be ignored.
    home_trig_level_param = MksServo.EndStopLevel.Low if hasattr(MksServo, 'EndStopLevel') else 0 # Default/Guess

    print("WARNING: The MksServo Python library's set_home() may not fully support configuring 'noLimit' (stall) homing.")
    print("         Servo must be pre-configured for 'noLimit' mode with appropriate parameters (Hm_Mode=noLimit on menu, low Hm_Ma, suitable Reverse Angle) via its LCD menu,")
    print("         as this script might not be able to set all required raw CAN parameters for stall homing via library calls.")
    homing_dir_str = 'CW' if homing_direction_val == (MksServo.Direction.CW if hasattr(MksServo, 'Direction') else 0) else 'CCW'
    print(f"Attempted homing with: Speed={homing_speed_rpm}, Dir={homing_dir_str}")

    if gui_ready and root and root.winfo_exists():
        if not messagebox.askokcancel("Confirm Homing", 
                                      "Ensure motor path is clear for homing to hard stop!\n"
                                      f"Homing with Speed: {homing_speed_rpm} RPM, Direction: {homing_dir_str}.\n"
                                      "Servo MUST be pre-configured for 'noLimit' mode via its LCD menu (Hm_Mode=noLimit, low Hm_Ma, suitable Reverse Angle) as this script may not set all required raw CAN parameters for stall homing.\n\nProceed with library's homing attempt?"):
            print("Homing cancelled by user.")
            return
    else: print("Headless mode: Proceeding with homing attempt. ENSURE SAFETY AND PRE-CONFIGURATION.")

    try:
        print("Attempting to configure general homing parameters via servo.set_home()...")
        # Using POSITIONAL arguments for set_home as per MKS example: set_home(level, direction, speed, enable_end_limit_func)
        # The MKS Manual for CAN CMD 90H, byte7 is 'mode' (0=Limit, 1=noLimit).
        # The Python library set_home() does NOT expose this 'mode' parameter.
        # This means this call likely configures for LIMIT SWITCH homing by default.
        # For 'noLimit' homing to work, the servo must already be in 'noLimit' mode (e.g. set via its menu).
        set_home_result = servo_wrapper.set_home(
            home_trig_level_param, 
            homing_direction_val, 
            homing_speed_rpm,
            endlimit_after_home_setting 
        )
        print(f"set_home result: {set_home_result} (Note: This may not have set 'noLimit' mode if servo wasn't pre-configured)")
        
        is_set_home_command_success = False # Check SuccessStatus
        if hasattr(MksServo, 'SuccessStatus') and hasattr(MksServo.SuccessStatus, 'Success') and isinstance(set_home_result, MksServo.SuccessStatus):
            is_set_home_command_success = (set_home_result == MksServo.SuccessStatus.Success)
        elif isinstance(set_home_result, int) and set_home_result == 1: # Common success value
            is_set_home_command_success = True

        if is_set_home_command_success:
            print("Initiating homing sequence (b_go_home)...")
            homing_run_result = servo_wrapper.b_go_home() 
            print(f"Homing sequence completed. Result from b_go_home(): {homing_run_result}")

            is_homing_physical_success = False # Check GoHomeResult
            if hasattr(MksServo, 'GoHomeResult') and hasattr(MksServo.GoHomeResult, 'Success') and isinstance(homing_run_result, MksServo.GoHomeResult):
                 is_homing_physical_success = (homing_run_result == MksServo.GoHomeResult.Success)
            elif isinstance(homing_run_result, int) and homing_run_result == 2: # Manual: CAN CMD 91H response status 2 = success
                 is_homing_physical_success = True

            if is_homing_physical_success:
                print("Homing reported successful by servo. Reading position to set new offset.")
                time.sleep(0.2) # Let servo settle
                pos_after_home = servo_wrapper.read_encoder_value_addition()
                if pos_after_home is not None and isinstance(pos_after_home, int):
                    library_feedback_raw_offset_at_zero = pos_after_home # This should ideally be 0 if homing sets absolute zero
                    print(f"New display zero offset after homing: {library_feedback_raw_offset_at_zero} (current feedback units)")
                    current_output_angle_deg = 0.0
                    is_calibrated = FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT is not None
                    if app_running and root and root.winfo_exists():
                        update_angle_display(0.0, is_calibrated) # Display 0.0 or 0 raw units
                        messagebox.showinfo("Homing", "Homing successful. Display offset updated.")
                else:
                    print("Could not read position after homing to set offset.")
                    if gui_ready and root and root.winfo_exists(): messagebox.showerror("Homing Error", "Homing ok, but failed to read position after.")
            else:
                print(f"Homing failed or result not expected success value. Servo Result: {homing_run_result}")
                if gui_ready and root and root.winfo_exists(): messagebox.showerror("Homing Error", f"Homing failed. Servo Result: {homing_run_result}")
        else:
            msg = f"set_home command itself failed or reported not success: {set_home_result}. Cannot initiate homing."
            print(msg)
            if gui_ready and root and root.winfo_exists(): messagebox.showerror("Homing Config Error", msg)

    except AttributeError as ae: # Catch errors if enums like MksServo.Direction etc. are not found
        msg = f"Homing Error: MksServo library attribute error (likely missing methods or enums like EndStopLevel/Direction/Enable/GoHomeResult): {ae}"
        print(msg)
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Homing Error", msg)
        traceback.print_exc()
    except Exception as e:
        msg = f"Error during homing: {e}"
        print(msg)
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Homing Error", msg)
        traceback.print_exc()

def on_emergency_stop_button(): 
    global servo_wrapper, e_stop_active, gui_ready, root
    if servo_wrapper is None: 
        if gui_ready and root and root.winfo_exists(): messagebox.showerror("Error", "Servo not connected.")
        else: print("Error: Servo not connected for E-STOP.")
        return
    print("Sending EMERGENCY STOP command...")
    try:
        result = servo_wrapper.emergency_stop_motor()
        print(f"E-Stop cmd sent. Lib Result: {result}") 
        e_stop_active = True 
        update_gui_for_e_stop_status(True) 
        if app_running and root and root.winfo_exists(): 
            messagebox.showinfo("E-STOP", f"E-Stop cmd sent (Lib Result: {result}). Motion blocked.")
        else: print("E-STOP: GUI not available for confirmation.")
    except AttributeError: 
        err_msg = "Library Error: No 'emergency_stop_motor' method."
        if app_running and root and root.winfo_exists(): messagebox.showerror("Library Error", err_msg)
        else: print(err_msg)
        traceback.print_exc()
    except Exception as e: 
        err_msg_detail = f"E-STOP Error: {e}"
        if app_running and root and root.winfo_exists(): messagebox.showerror("Servo Command Error", err_msg_detail)
        else: print(f"{err_msg_detail} (GUI unavailable)")
        traceback.print_exc()

def update_angle_display(value, is_calibrated_degrees=True): 
    global current_angle_label, app_running, root, current_feedback_scaling_display_tkvar, FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT
    if app_running and root and root.winfo_exists(): 
        new_text = ""
        if is_calibrated_degrees:
            new_text = f"Output Angle: {value:.3f}°" 
            if current_feedback_scaling_display_tkvar: 
                fupmd_val = FEEDBACK_UNITS_PER_MOTOR_DEGREE_CURRENT
                current_feedback_scaling_display_tkvar.set(f"{fupmd_val:.4f}" if fupmd_val is not None else "100.0 (cdeg default)")
        else:
            new_text = f"Output (Raw Units): {int(value) if isinstance(value, (float, int)) else value}" 
            if current_feedback_scaling_display_tkvar: current_feedback_scaling_display_tkvar.set("N/A (Uncalibrated)")

        if current_angle_label and (not hasattr(update_angle_display, 'last_gui_text') or update_angle_display.last_gui_text != new_text):
            update_angle_display.last_gui_text = new_text
            try: 
                current_angle_label.config(text=new_text)
            except tk.TclError:
                 if app_running : print("Update_angle_display: Label error, window closing.")

def update_gui_for_e_stop_status(is_estopped: bool): 
    global angle_entry, set_angle_gui_button, set_zero_button, home_button
    global speed_entry, accel_entry, subdivision_combobox, apply_config_button, interpolation_check
    global estop_button 

    motion_control_widget_state = tk.DISABLED if is_estopped else tk.NORMAL
    
    # List of widgets to enable/disable for motion control
    widgets_for_motion = [angle_entry, set_angle_gui_button, set_zero_button, home_button,
                           speed_entry, accel_entry]
    # Config widgets might be handled differently or also disabled
    widgets_for_config = [subdivision_combobox, apply_config_button, interpolation_check]

    for widget in widgets_for_motion:
        if widget and isinstance(widget, (ttk.Entry, ttk.Button, ttk.Scale, ttk.Combobox, ttk.Checkbutton)):
            try: widget.config(state=motion_control_widget_state)
            except tk.TclError: pass 

    for widget in widgets_for_config: # Config widgets also disabled during E-Stop
        if widget and isinstance(widget, (ttk.Entry, ttk.Button, ttk.Scale, ttk.Combobox, ttk.Checkbutton)):
            try: widget.config(state=motion_control_widget_state)
            except tk.TclError: pass


    if estop_button and isinstance(estop_button, ttk.Button): 
        try:
            estop_button.config(style="EstopActive.TButton" if is_estopped else "Emergency.TButton")
        except tk.TclError: pass

def on_closing(): 
    global stop_reading_thread, app_running, root, reading_thread
    print("Quit initiated.")
    if not app_running: print("Closing already started."); return
    user_wants_to_quit = True 
    if threading.current_thread() is threading.main_thread() and root and root.winfo_exists():
         if not messagebox.askokcancel("Quit", "Do you want to quit? This will disconnect CAN."):
            print("Quit cancelled by user."); user_wants_to_quit = False
    if user_wants_to_quit:
        print("Proceeding with shutdown.")
        app_running = False; stop_reading_thread = True 
        print("Signaled reading thread to stop. Calling disconnect_can...")
        disconnect_can() 
        if root: 
            try: print("Destroying Tkinter root window..."); root.destroy(); root = None; print("Tkinter root destroyed.")
            except tk.TclError as e: print(f"Tkinter TclError during destroy: {e}")
        print("Application closed.")

# --- GUI Setup ---
root = tk.Tk() 
root.title("Servo Control Panel V2.5 (Calibration Support)")

current_speed_tkvar = tk.IntVar(value=1000)
current_acceleration_tkvar = tk.IntVar(value=255)
current_subdivision_tkvar = tk.IntVar(value=0)
current_interpolation_enabled_tkvar = tk.BooleanVar(value=True)
current_feedback_scaling_display_tkvar = tk.StringVar(value="100.0000 (cdeg default)") # Changed label

connection_frame = ttk.LabelFrame(root, text="Connection & Homing", padding="10")
connection_frame.pack(padx=10, pady=5, fill="x", expand=True) 
connect_button = ttk.Button(connection_frame, text="Connect", command=connect_can) 
connect_button.pack(side=tk.LEFT, padx=5)
home_button = ttk.Button(connection_frame, text="Home Motor (Sensorless - EXPERIMENTAL)", command=on_home_motor_button)
home_button.pack(side=tk.LEFT, padx=15)

config_frame = ttk.LabelFrame(root, text="Servo Configuration", padding="10")
config_frame.pack(padx=10, pady=5, fill="x", expand=True)
ttk.Label(config_frame, text="Speed (RPM):").grid(row=0, column=0, sticky="w", padx=5, pady=2)
speed_entry = ttk.Entry(config_frame, textvariable=current_speed_tkvar, width=7)
speed_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=2) 
ttk.Label(config_frame, text="Accel (1-255):").grid(row=1, column=0, sticky="w", padx=5, pady=2)
accel_entry = ttk.Entry(config_frame, textvariable=current_acceleration_tkvar, width=7)
accel_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2) 
ttk.Label(config_frame, text="Subdivision Code:").grid(row=0, column=2, sticky="w", padx=15, pady=2) 
subdivision_combobox = ttk.Combobox(config_frame, textvariable=current_subdivision_tkvar, values=SUBDIVISION_CODES_FOR_GUI, width=5, state="readonly")
subdivision_combobox.grid(row=0, column=3, sticky="ew", padx=5, pady=2) 
subdivision_combobox.set(0) 
interpolation_check = ttk.Checkbutton(config_frame, text="Interpolation On", variable=current_interpolation_enabled_tkvar)
interpolation_check.grid(row=1, column=2, columnspan=2, sticky="w", padx=15, pady=2)
apply_config_button = ttk.Button(config_frame, text="Apply Config to Servo", command=set_servo_configuration_from_gui) 
apply_config_button.grid(row=2, column=0, columnspan=4, pady=5)
config_frame.columnconfigure(1, weight=1)
config_frame.columnconfigure(3, weight=1)

control_frame = ttk.LabelFrame(root, text="Motion Control", padding="10")
control_frame.pack(padx=10, pady=5, fill="x", expand=True)
cf_left_frame = ttk.Frame(control_frame)
cf_left_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
cf_right_frame = ttk.Frame(control_frame)
cf_right_frame.pack(side=tk.RIGHT, fill=tk.X) 
ttk.Label(cf_left_frame, text="Output Angle (°):").pack(side=tk.LEFT, padx=5)
angle_entry = ttk.Entry(cf_left_frame, width=10)
angle_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
angle_entry.insert(0, "0.0")
set_angle_gui_button = ttk.Button(cf_right_frame, text="Set Angle", command=set_output_angle_from_gui) 
set_angle_gui_button.pack(side=tk.LEFT, padx=5)
set_zero_button = ttk.Button(cf_right_frame, text="Set Zero (Logical)", command=on_set_zero_button) 
set_zero_button.pack(side=tk.LEFT, padx=10)
estop_button = ttk.Button(cf_right_frame, text="E-STOP", command=on_emergency_stop_button, style="Emergency.TButton")
estop_button.pack(side=tk.LEFT, padx=10)
s = ttk.Style(); 
s.configure("Emergency.TButton", foreground="white", background="red", font=('Helvetica', '10', 'bold'))
s.configure("EstopActive.TButton", foreground="black", background="yellow", font=('Helvetica', '10', 'bold'))

display_frame = ttk.LabelFrame(root, text="Status", padding="10")
display_frame.pack(padx=10, pady=5, fill="x", expand=True)
current_angle_label = ttk.Label(display_frame, text="Output Angle: N/A") 
current_angle_label.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)
ttk.Label(display_frame, text="FeedbackUnits/MotorDeg:").pack(side=tk.LEFT, padx=10) # Changed Label
current_ppmd_label = ttk.Label(display_frame, textvariable=current_feedback_scaling_display_tkvar, anchor="w")
current_ppmd_label.pack(side=tk.LEFT, padx=5, expand=True, fill=tk.X)

# --- Main Application Logic ---
reading_thread = None
if __name__ == "__main__":
    app_running, gui_ready = True, False 
    if connect_can(): 
        stop_reading_thread = False
        reading_thread = threading.Thread(target=read_current_angle_periodically, daemon=True); reading_thread.start()
    else: 
        if 'root' in locals() and root and isinstance(root, tk.Tk) and root.winfo_exists():
             messagebox.showwarning("Startup Warning", "Could not connect CAN. Check setup & 'Connect' button.")
        else: print("Startup Warning: Could not connect CAN. GUI not available for messagebox.")

    if 'root' not in locals() or not isinstance(root, tk.Tk): 
        print("CRITICAL: Tkinter root not properly initialized before mainloop.")
        root = tk.Tk(); root.title("Error - Root Recreated")
        ttk.Label(root, text="Error: Main window was not properly initialized. Please restart.").pack(padx=20, pady=20)

    gui_ready = True
    update_gui_for_e_stop_status(e_stop_active) 
    if current_subdivision_tkvar is not None: # Ensure tkvar exists
        update_feedback_scaling_for_subdivision(current_subdivision_tkvar.get())
    else: # Should not happen
        if current_feedback_scaling_display_tkvar is not None: current_feedback_scaling_display_tkvar.set("Error: Subdiv var not ready")


    root.protocol("WM_DELETE_WINDOW", on_closing)
    try: print("Starting Tkinter mainloop..."); root.mainloop()
    except KeyboardInterrupt: 
        print("Keyboard interrupt received.")
        if app_running: on_closing() 
    except tk.TclError as e:
        if "application has been destroyed" in str(e).lower(): print("Tkinter mainloop TclError on exit (expected).")
        else: print(f"Unexpected Tkinter TclError: {e}"); traceback.print_exc()
    finally:
        print("Mainloop exited or exception. Performing final cleanup...")
        if app_running: on_closing()
        else: 
            if reading_thread and reading_thread.is_alive():
                print("Main finally: Reading thread still alive, attempting join...")
                stop_reading_thread = True 
                reading_thread.join(timeout=1.0)
                if reading_thread.is_alive(): print("Warning: Reading thread did not join in main finally.")
        print("Application terminated.")