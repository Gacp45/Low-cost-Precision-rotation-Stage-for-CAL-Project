import tkinter as tk
from tkinter import ttk, messagebox
import can
from mks_servo_can import MksServo # Using the uploaded library version
# Attempt to import the specific error and enums from the library
try:
    from mks_servo_can.mks_servo import InvalidResponseError 
    from mks_servo_can.mks_enums import Enable as MksEnableEnum 
    from mks_servo_can.mks_enums import SuccessStatus
    print("DEBUG: Successfully imported InvalidResponseError, MksEnableEnum, SuccessStatus from library.")
except ImportError as e:
    print(f"DEBUG: Could not import specific error/enums from library: {e}. Using placeholders.")
    # Define placeholders if direct import fails, to prevent crashes if library structure is unexpected
    # This is a fallback, ideally the direct imports above should work with the user's library.
    from enum import Enum
    class InvalidResponseError(Exception): pass
    class MksEnableEnum(Enum): Disable = 0; Enable = 1 
    class SuccessStatus(Enum): Fail = 0; Success = 1
    
import threading
import time
import traceback
from enum import Enum # For placeholder enums if MksEnableEnum/SuccessStatus are not found

# --- Constants ---
CAN_INTERFACE = "socketcan"
CAN_CHANNEL = "can0"
CAN_BITRATE = 500000
SERVO_CAN_ID = 1 
GEAR_RATIO = 17.0

MAX_SPEED = 1000 
MIN_SPEED = 10
MAX_ACCELERATION = 255 
MIN_ACCELERATION = 1
DEFAULT_SPEED = 500
DEFAULT_ACCELERATION = 100

MOTOR_CDEG_MIN = -8388608 
MOTOR_CDEG_MAX = 8388607

APP_TITLE = "Rotation Stage Control v8.2 (Cleaned)"
CONNECT_BUTTON_TEXT = "Connect"
DISCONNECT_BUTTON_TEXT = "Disconnect"
STATUS_DEFAULT_TEXT = "Current Output Angle: N/A"
SET_ZERO_SUCCESS_MSG = "Motor internal zero reset. Display offset updated."
SET_ZERO_CAPTURE_FAIL_WARN_MSG = "Set Zero: Failed to read an updated offset. Display may be inaccurate."
SET_ZERO_UNEXPECTED_RESPONSE_WARN_MSG = ("Set Zero command sent, but servo returned an unexpected status.\n"
                                       "The library could not confirm success (e.g., status 255 received).\n"
                                       "Offset reading will be attempted, but verify motor behavior.")

SUBDIVISION_SETTINGS = {
    "1 (Full Step)": 1, "2 (Half Step)": 2, "4": 4, "8": 8,
    "16": 16, "32": 32, "64": 64, "128": 128, "256": 255,
}
DEFAULT_SUBDIVISION_NAME = "16"

ANGLE_READ_INTERVAL_S = 0.1
ANGLE_QUERY_FREQUENCY = 1
ANGLE_LOG_INTERVAL_COUNT = 20 # Log angle every 2 seconds if interval is 0.1s

print("--------------------------------------------------------------------------")
print(f"SCRIPT USING: MksServo library with 3-argument constructor: MksServo(bus, notifier, can_id).")
print(f"Using methods from your provided library files.")
print("--------------------------------------------------------------------------")
print(f"GEAR_RATIO: {GEAR_RATIO}")

# --- Global Variables ---
bus: can.interface.Bus = None
notifier: can.Notifier = None
servo_wrapper: MksServo = None
current_output_angle_deg: float = 0.0
stop_reading_thread: bool = False
gui_ready: bool = False
app_running: bool = True
e_stop_active: bool = False
library_motor_offset_cdeg: int = 0

reading_thread: threading.Thread = None
root: tk.Tk = None

# GUI Widget global variables
speed_value_label: ttk.Label = None
accel_value_label: ttk.Label = None
current_angle_label: ttk.Label = None
status_bar_label: ttk.Label = None
connect_button: ttk.Button = None
angle_entry: ttk.Entry = None
set_angle_button: ttk.Button = None
set_zero_button: ttk.Button = None
estop_button: ttk.Button = None
speed_scale: ttk.Scale = None
accel_scale: ttk.Scale = None
subdivision_combobox: ttk.Combobox = None
set_subdivision_button: ttk.Button = None
subdivision_var: tk.StringVar = None
subdivision_interpolation_var: tk.IntVar = None 
enable_interpolation_button: ttk.Checkbutton = None


# --- CAN Connection and Disconnection ---
def connect_can_interface():
    global bus, notifier, servo_wrapper, app_running, e_stop_active, library_motor_offset_cdeg
    if not app_running: return False
    disconnect_can_interface()
    e_stop_active = False
    library_motor_offset_cdeg = 0
    update_status_bar("Attempting connection...")
    print("Attempting CAN connection...")
    try:
        bus = can.interface.Bus(interface=CAN_INTERFACE, channel=CAN_CHANNEL, bitrate=CAN_BITRATE)
        if bus is None: raise ConnectionError("CAN bus object is None.")
        
        initial_listeners = [] 
        notifier = can.Notifier(bus, initial_listeners)
        
        servo_wrapper = MksServo(bus, notifier, SERVO_CAN_ID) 

        if hasattr(servo_wrapper, 'can_id'): 
            print(f"Connected. Servo Node ID (from servo_wrapper.can_id): {servo_wrapper.can_id}.")
        else:
            print(f"Connected. Servo Node ID (using SERVO_CAN_ID param): {SERVO_CAN_ID}. ('can_id' attribute not found).")

        if servo_wrapper:
            print("Attempting initial angle read for offset (using 'read_encoder_value_addition()').")
            try:
                initial_cdeg_val = servo_wrapper.read_encoder_value_addition()
                print(f"  Raw initial read from read_encoder_value_addition(): {initial_cdeg_val} (type: {type(initial_cdeg_val)})")
                
                if isinstance(initial_cdeg_val, int):
                    library_motor_offset_cdeg = initial_cdeg_val
                    print(f"  Initial library_motor_offset_cdeg set to: {library_motor_offset_cdeg} (motor cdeg).")
                elif initial_cdeg_val is None:
                     print(f"  read_encoder_value_addition() returned None. Offset remains 0.")
                else:
                    print(f"  WARNING: read_encoder_value_addition() returned unexpected type: {type(initial_cdeg_val)}. Offset remains 0.")

            except AttributeError:
                error_msg_attr = "ERROR: 'read_encoder_value_addition()' method not found in your MksServo library."
                print(f"  {error_msg_attr}")
                if gui_ready: messagebox.showwarning("Library Method Missing", error_msg_attr)
            except Exception as e_read:
                print(f"  Error during initial angle read: {e_read}")
                if gui_ready: messagebox.showwarning("Connection Warning", f"Could not read initial servo angle: {e_read}")
        
        update_gui_for_connection_status(connected=True)
        update_status_bar("CAN Connected.")
        return True
    except TypeError as te: 
        error_msg = (f"CAN connection error (TypeError): {te}.\nThis usually means the MksServo library "
                     f"found in your environment has a different constructor signature than expected "
                     f"(expecting 3 arguments: bus, notifier, id).")
        print(error_msg); traceback.print_exc() # Keep traceback for this critical error
        if gui_ready: messagebox.showerror("Library Initialization Error", error_msg)
        bus, notifier, servo_wrapper = None, None, None 
        update_gui_for_connection_status(connected=False)
        update_status_bar("CAN Connection Failed (Lib Init Error).")
        return False
    except Exception as e: 
        error_msg = f"CAN connection error: {e}"
        print(error_msg) # No traceback for general connection errors unless debugging
        if gui_ready: messagebox.showerror("CAN Connection Error", f"{error_msg}\nCheck console.")
        bus, notifier, servo_wrapper = None, None, None
        update_gui_for_connection_status(connected=False)
        update_status_bar("CAN Connection Failed.")
        return False

def disconnect_can_interface():
    global bus, notifier, servo_wrapper, reading_thread, stop_reading_thread
    print("Disconnect_can_interface called.")
    if reading_thread and reading_thread.is_alive() and threading.current_thread() != reading_thread:
        print("Signaling angle reading thread to stop...")
        stop_reading_thread = True 
        reading_thread.join(timeout=2.0)
        if reading_thread.is_alive(): print("Warning: Angle reading thread did not stop cleanly.")
        else: print("Angle reading thread stopped.")
    if notifier:
        try: notifier.stop(timeout=1.0); print("Notifier stopped.")
        except Exception as e: print(f"Error stopping notifier: {e}")
        notifier = None
    if bus:
        try: bus.shutdown(); print("CAN bus shutdown.")
        except Exception as e: print(f"Error shutting bus: {e}")
        bus = None
    servo_wrapper = None; print("CAN resources released.")
    update_gui_for_connection_status(connected=False)
    update_status_bar("CAN Disconnected.")
    if current_angle_label: current_angle_label.config(text=STATUS_DEFAULT_TEXT)

# --- Servo Control Functions ---
def move_motor_absolute(target_output_angle_deg_str):
    global servo_wrapper, e_stop_active, speed_scale, accel_scale
    if e_stop_active: messagebox.showwarning("E-STOP Active", "Motion blocked."); return
    if servo_wrapper is None: messagebox.showerror("Error", "Servo not connected."); return
    try:
        target_output_angle_deg = float(target_output_angle_deg_str)
        motor_target_angle_deg = target_output_angle_deg * GEAR_RATIO
        motor_target_angle_cdeg = int(motor_target_angle_deg * 100)

        if not (MOTOR_CDEG_MIN <= motor_target_angle_cdeg <= MOTOR_CDEG_MAX):
            messagebox.showerror("Input Error", f"Target motor angle ({motor_target_angle_cdeg} cdeg) exceeds limits."); return
        
        speed_val = int(speed_scale.get())
        accel_val = int(accel_scale.get())

        print(f"Requesting output: {target_output_angle_deg:.2f}°, Motor cdeg: {motor_target_angle_cdeg}, Speed: {speed_val}, Accel: {accel_val}")
        servo_wrapper.run_motor_absolute_motion_by_axis(speed_val, accel_val, motor_target_angle_cdeg)
        print(f"Command 'run_motor_absolute_motion_by_axis' sent.")
        update_status_bar(f"Moving to {target_output_angle_deg:.2f}°...")
    except ValueError: 
        messagebox.showerror("Input Error", "Invalid angle format.")
    except AttributeError as ae:
        messagebox.showerror("Library Error", f"MksServo method error: {ae}. '{ae.name}' might be missing.")
    except Exception as e: 
        messagebox.showerror("Servo Command Error", f"Move error: {e}")

def on_set_zero_button():
    global servo_wrapper, current_output_angle_deg, library_motor_offset_cdeg, e_stop_active
    if e_stop_active: messagebox.showwarning("E-STOP Active", "Cannot set zero."); return
    if servo_wrapper is None: messagebox.showerror("Error", "Servo not connected."); return
    
    print("Attempting 'set_current_axis_to_zero()'.")
    command_sent_ok = False
    ire_occurred_flag = False 
    try:
        servo_wrapper.set_current_axis_to_zero() 
        print("  'set_current_axis_to_zero' command sent (library did not raise error).")
        command_sent_ok = True
        time.sleep(0.1)
    except InvalidResponseError as ire: 
        print(f"  WARNING during 'set_current_axis_to_zero': {ire}")
        if gui_ready: messagebox.showwarning("Set Zero - Unexpected Response", SET_ZERO_UNEXPECTED_RESPONSE_WARN_MSG)
        update_status_bar("Set Zero: Servo returned unexpected status (255).")
        command_sent_ok = True # Command was sent, but lib couldn't parse response as success
        ire_occurred_flag = True
    except AttributeError as ae: 
        messagebox.showerror("Library Error", f"MksServo method error: {ae}. '{ae.name}' missing.")
        update_status_bar("Set zero failed (method missing)."); return 
    except Exception as e: 
        print(f"Error during 'set_current_axis_to_zero': {e}")
        if gui_ready: messagebox.showerror("Servo Command Error", f"Error during 'set zero': {e}")
        update_status_bar("Set zero failed (command error)."); return 

    current_abs_cdeg_at_new_zero = None
    valid_read_for_offset = False
    try:
        current_abs_cdeg_at_new_zero = servo_wrapper.read_encoder_value_addition()
        if isinstance(current_abs_cdeg_at_new_zero, int):
            valid_read_for_offset = True
            print(f"  Servo's reported cdeg after set_zero attempt: {current_abs_cdeg_at_new_zero}. This becomes new offset base.")
        else:
            print(f"  Warning: read_encoder_value_addition returned non-integer: {current_abs_cdeg_at_new_zero}.")
    except AttributeError: print("  ERROR: 'read_encoder_value_addition' not found. Cannot update offset.")
    except Exception as e_read_offset: print(f"  Error reading offset: {e_read_offset}")

    if valid_read_for_offset:
        library_motor_offset_cdeg = current_abs_cdeg_at_new_zero
        current_output_angle_deg = 0.0 
        update_angle_display_on_gui(current_output_angle_deg)
        if command_sent_ok and not ire_occurred_flag: 
            messagebox.showinfo("Set Zero", SET_ZERO_SUCCESS_MSG)
            update_status_bar("Current position set as zero.")
    elif command_sent_ok: # Command sent (even if bad response) but offset read failed
        messagebox.showwarning("Set Zero - Offset Read Failed", SET_ZERO_CAPTURE_FAIL_WARN_MSG)
        if not ire_occurred_flag: update_status_bar("Set Zero: Offset read failed.")


def on_emergency_stop_button():
    global servo_wrapper, e_stop_active
    if servo_wrapper is None: messagebox.showerror("Error", "Servo not connected."); return
    print("Sending 'emergency_stop_motor()'.")
    try:
        result = servo_wrapper.emergency_stop_motor() 
        print(f"E-Stop command sent. Library Result: {result}"); e_stop_active = True
        update_gui_for_e_stop_status(is_estopped=True)
        update_status_bar("E-STOP ACTIVATED. Reconnect to clear.")
        messagebox.showwarning("E-STOP", f"E-Stop cmd sent (Lib Result: {result}). Motion blocked.")
    except AttributeError as ae: 
        err_msg = f"Library Error: 'emergency_stop_motor' method not available: {ae}."; print(err_msg)
        if gui_ready: messagebox.showerror("Library Error", err_msg)
    except Exception as e: 
        print(f"E-STOP Error: {e}")
        if gui_ready: messagebox.showerror("Servo Command Error", f"E-STOP Error: {e}")
        e_stop_active = True; update_gui_for_e_stop_status(is_estopped=True)
        update_status_bar("E-STOP attempted with error.")

def on_set_subdivision_button():
    global servo_wrapper, e_stop_active, subdivision_var 
    if e_stop_active: messagebox.showwarning("E-STOP Active", "Cannot change subdivision."); return
    if servo_wrapper is None: messagebox.showerror("Error", "Servo not connected."); return

    selected_subdivision_name = subdivision_var.get()
    subdivision_code = SUBDIVISION_SETTINGS.get(selected_subdivision_name)
    if subdivision_code is None: messagebox.showerror("Error", f"Invalid subdivision: {selected_subdivision_name}"); return

    print(f"Attempting 'set_subdivisions({subdivision_code})' for '{selected_subdivision_name}'.")
    update_status_bar(f"Setting subdivision to {selected_subdivision_name}...")
    try:
        if hasattr(servo_wrapper, 'set_subdivisions'):
            result_status = servo_wrapper.set_subdivisions(subdivision_code)
            if isinstance(result_status, SuccessStatus) and result_status == SuccessStatus.Success:
                msg = f"Subdivision set to {selected_subdivision_name} successfully."
                print(f"  SUCCESS: {msg}"); messagebox.showinfo("Subdivision Set", msg)
                update_status_bar(f"Subdivision set to {selected_subdivision_name}.")
            elif isinstance(result_status, SuccessStatus) and result_status == SuccessStatus.Fail:
                msg = f"Servo responded FAIL for set subdivision to {selected_subdivision_name}."
                print(f"  SERVO FAIL: {msg}"); messagebox.showerror("Servo Error", msg)
                update_status_bar(f"Set subdivision failed (servo fail).")
            else: 
                msg = f"Subdivision cmd for {selected_subdivision_name} sent. Lib returned: {result_status} (unexpected)."
                print(f"  UNEXPECTED LIB STATUS: {msg}"); messagebox.showwarning("Subdivision - Check Servo", msg)
                update_status_bar(f"Subdivision cmd ({selected_subdivision_name}) sent, unconfirmed.")
        elif hasattr(servo_wrapper, 'bus') and hasattr(servo_wrapper, 'can_id'): # Fallback to raw
            print("  'set_subdivisions()' not found. Attempting raw CAN send.")
            can_id_to_send = 0x140 + servo_wrapper.can_id 
            msg_data = [0x77, 0x00, 0x00, 0x00, subdivision_code, 0x00, 0x00, 0x00]
            message_to_send = can.Message(arbitration_id=can_id_to_send, data=msg_data, is_extended_id=False)
            servo_wrapper.bus.send(message_to_send)
            raw_msg = f"Raw CAN cmd for subdivision {selected_subdivision_name} sent. No confirmation."
            print(f"  Sent Raw CAN: ID={hex(can_id_to_send)}, Data={msg_data}"); messagebox.showinfo("Subdivision Sent (Raw)", raw_msg)
            update_status_bar(f"Subdivision cmd ({selected_subdivision_name}) sent raw.")
        else:
            err_cap = "Cannot set subdivision: Neither 'set_subdivisions()' nor raw CAN send (bus/can_id) available."
            print(f"  ERROR: {err_cap}"); messagebox.showerror("Library Error", err_cap)
            update_status_bar("Subdivision failed (no method).")
    except InvalidResponseError as ire: 
        print(f"  InvalidResponseError during 'set_subdivisions': {ire}"); messagebox.showerror("Servo Error", f"Set subdivision failed. Servo status: {ire}")
        update_status_bar(f"Set subdivision failed (servo error).")
    except AttributeError as ae: 
        print(f"  AttributeError during subdivision: {ae}"); messagebox.showerror("Library Error", f"Subdivision error: {ae}")
        update_status_bar("Set subdivision error (AttributeError).")
    except Exception as e:
        print(f"  General ERROR setting subdivision: {e}"); messagebox.showerror("Command Error", f"Error setting subdivision: {e}")
        update_status_bar("Set subdivision error (Exception).")

def on_toggle_subdivision_interpolation():
    global servo_wrapper, e_stop_active, subdivision_interpolation_var
    if e_stop_active: messagebox.showwarning("E-STOP Active", "Cannot change interpolation."); return
    if servo_wrapper is None: messagebox.showerror("Error", "Servo not connected."); return

    enable_state_int = subdivision_interpolation_var.get()
    enable_state_for_lib = MksEnableEnum(enable_state_int)
    state_str = "Enable" if enable_state_int == 1 else "Disable"
    print(f"Attempting to {state_str} subdivision interpolation (Lib val: {enable_state_for_lib}).")
    update_status_bar(f"{state_str}ing interpolation...")
    try:
        if hasattr(servo_wrapper, 'set_subdivision_interpolation'):
            result_status = servo_wrapper.set_subdivision_interpolation(enable_state_for_lib)
            if isinstance(result_status, SuccessStatus) and result_status == SuccessStatus.Success:
                msg = f"Subdivision interpolation {state_str.lower()}d successfully."
                print(f"  SUCCESS: {msg}"); messagebox.showinfo("Interpolation Set", msg)
                update_status_bar(f"Interpolation {state_str.lower()}d.")
            elif isinstance(result_status, SuccessStatus) and result_status == SuccessStatus.Fail:
                msg = f"Servo responded FAIL to {state_str.lower()} interpolation."
                print(f"  SERVO FAIL: {msg}"); messagebox.showerror("Servo Error", msg)
                update_status_bar(f"Interpolation {state_str.lower()} failed (servo fail).")
            else:
                msg = f"Cmd to {state_str.lower()} interpolation sent. Lib returned: {result_status} (unexpected)."
                print(f"  UNEXPECTED LIB STATUS: {msg}"); messagebox.showwarning("Interpolation - Check Servo", msg)
                update_status_bar(f"Interpolation cmd sent, unconfirmed.")
        else:
            err_msg = "ERROR: 'set_subdivision_interpolation' method not found."; print(err_msg)
            messagebox.showerror("Library Method Missing", err_msg)
            update_status_bar("Interpolation cmd failed (method missing).")
    except InvalidResponseError as ire:
        print(f"  InvalidResponseError for interpolation: {ire}"); messagebox.showerror("Servo Error", f"Interpolation failed. Servo status: {ire}")
        update_status_bar(f"Interpolation failed (servo error).")
    except Exception as e:
        print(f"Error setting interpolation: {e}"); messagebox.showerror("Command Error", f"Error setting interpolation: {e}")
        update_status_bar("Interpolation cmd failed (exception).")

# --- Angle Reading Thread ---
def read_current_angle_periodically():
    global current_output_angle_deg, servo_wrapper, stop_reading_thread, app_running, gui_ready, e_stop_active, library_motor_offset_cdeg
    # print("Angle reading thread started (using 'read_encoder_value_addition()').") # Less verbose
    loop_count = 0
    while not stop_reading_thread and app_running:
        if gui_ready and servo_wrapper and not e_stop_active:
            loop_count += 1; calculated_out_angle = None; raw_cdeg_from_lib_reading = None
            if loop_count % ANGLE_QUERY_FREQUENCY == 0:
                try:
                    raw_cdeg_from_lib_reading = servo_wrapper.read_encoder_value_addition()
                    if isinstance(raw_cdeg_from_lib_reading, int):
                        relative_motor_cdeg = raw_cdeg_from_lib_reading - library_motor_offset_cdeg
                        motor_angle_deg_relative_to_zero = relative_motor_cdeg / 100.0
                        calculated_out_angle = motor_angle_deg_relative_to_zero / GEAR_RATIO
                        current_output_angle_deg = calculated_out_angle
                    elif raw_cdeg_from_lib_reading is None and loop_count % (ANGLE_LOG_INTERVAL_COUNT*10) == 0: # Log None less often
                        print(f"AngleRead: read_encoder_value_addition() returned None.")
                    elif loop_count % (ANGLE_LOG_INTERVAL_COUNT*2) == 0 : # Log other non-int less often
                        print(f"Warning: read_encoder_value_addition() returned non-integer: {raw_cdeg_from_lib_reading} (type: {type(raw_cdeg_from_lib_reading)})")
                except AttributeError: 
                    if loop_count % (ANGLE_LOG_INTERVAL_COUNT * 10) == 0: 
                        print(f"CRITICAL Reader: 'read_encoder_value_addition()' not found. Feedback stopped.")
                    pass 
                except Exception as e: 
                    if loop_count % (ANGLE_LOG_INTERVAL_COUNT*2) == 0: 
                        print(f"Error in angle reader query: {e}")
            
            if loop_count % ANGLE_LOG_INTERVAL_COUNT == 0 and gui_ready: 
                display_raw_feed = raw_cdeg_from_lib_reading if raw_cdeg_from_lib_reading is not None else 'N/A'
                display_calculated_angle = calculated_out_angle if calculated_out_angle is not None else f'{current_output_angle_deg:.3f} (stale)'
                # print(f"AngleRead (L{loop_count}): RawLib(cdeg)={display_raw_feed}, Offset(cdeg)={library_motor_offset_cdeg}, OutputAngle={display_calculated_angle}") # Make this optional
            
            if calculated_out_angle is not None and app_running and root and root.winfo_exists():
                try: root.after(0, update_angle_display_on_gui, calculated_out_angle)
                except tk.TclError:
                    if app_running: print("AngleRead: root.after failed, window closing."); break
        
        elif (not gui_ready or not servo_wrapper or e_stop_active) and loop_count % (ANGLE_LOG_INTERVAL_COUNT * 10) == 0 : 
             if e_stop_active : print("Angle reading paused (E-STOP).")
             elif not servo_wrapper : print("Angle reading paused (No Servo Connected).")
        time.sleep(ANGLE_READ_INTERVAL_S)
    print("Angle reading thread stopped.")

# --- GUI Update Functions --- (Mostly unchanged)
def update_angle_display_on_gui(angle_deg: float):
    global current_angle_label
    if app_running and current_angle_label and root and root.winfo_exists():
        new_text = f"Current Output Angle: {angle_deg:.3f}°"
        if not hasattr(update_angle_display_on_gui, 'last_gui_text') or update_angle_display_on_gui.last_gui_text != new_text:
            update_angle_display_on_gui.last_gui_text = new_text
            try: current_angle_label.config(text=new_text)
            except tk.TclError: pass 

def update_speed_label(value):
    global speed_value_label
    if speed_value_label and root and root.winfo_exists():
        speed_value_label.config(text=f"{float(value):.0f}")

def update_accel_label(value):
    global accel_value_label
    if accel_value_label and root and root.winfo_exists():
        accel_value_label.config(text=f"{float(value):.0f}")

def update_status_bar(message: str):
    global status_bar_label
    if app_running and status_bar_label and root and root.winfo_exists():
        try: status_bar_label.config(text=message)
        except tk.TclError: pass

def update_gui_for_connection_status(connected: bool):
    global connect_button, angle_entry, set_angle_button, set_zero_button, estop_button
    global speed_scale, accel_scale, subdivision_combobox, set_subdivision_button, current_angle_label
    global enable_interpolation_button, e_stop_active 

    widget_state = tk.NORMAL if connected else tk.DISABLED
    estop_button_state = tk.NORMAL if connected else tk.DISABLED
    
    if connect_button: connect_button.config(text=DISCONNECT_BUTTON_TEXT if connected else CONNECT_BUTTON_TEXT, 
                                           command=disconnect_can_interface if connected else handle_connect_button)
    if angle_entry: angle_entry.config(state=widget_state)
    if set_angle_button: set_angle_button.config(state=widget_state)
    if set_zero_button: set_zero_button.config(state=widget_state)
    if estop_button: estop_button.config(state=estop_button_state) 
    if speed_scale: speed_scale.config(state=widget_state)
    if accel_scale: accel_scale.config(state=widget_state)
    if subdivision_combobox: subdivision_combobox.config(state=widget_state)
    if set_subdivision_button: set_subdivision_button.config(state=widget_state)
    if enable_interpolation_button: enable_interpolation_button.config(state=widget_state)
    
    if not connected:
        if current_angle_label: current_angle_label.config(text=STATUS_DEFAULT_TEXT)
        e_stop_active = False 
        update_gui_for_e_stop_status(is_estopped=False)

def update_gui_for_e_stop_status(is_estopped: bool):
    global angle_entry, set_angle_button, set_zero_button, estop_button
    global speed_scale, accel_scale, subdivision_combobox, set_subdivision_button
    global enable_interpolation_button
    
    motion_control_widget_state = tk.DISABLED if is_estopped else tk.NORMAL
    
    if servo_wrapper: 
        if angle_entry: angle_entry.config(state=motion_control_widget_state)
        if set_angle_button: set_angle_button.config(state=motion_control_widget_state)
        if set_zero_button: set_zero_button.config(state=motion_control_widget_state)
        if speed_scale: speed_scale.config(state=motion_control_widget_state)
        if accel_scale: accel_scale.config(state=motion_control_widget_state)
        if subdivision_combobox: subdivision_combobox.config(state=motion_control_widget_state)
        if set_subdivision_button: set_subdivision_button.config(state=motion_control_widget_state)
        if enable_interpolation_button: enable_interpolation_button.config(state=motion_control_widget_state)

    if estop_button: 
        estop_button.config(style="EstopActive.TButton" if is_estopped else "Emergency.TButton")

# --- GUI Event Handlers ---
def handle_connect_button():
    global servo_wrapper, stop_reading_thread, reading_thread
    if servo_wrapper: 
        disconnect_can_interface()
    else: 
        if connect_can_interface(): 
            if reading_thread is None or not reading_thread.is_alive():
                print("Connect successful, starting new angle reading thread.")
                stop_reading_thread = False 
                reading_thread = threading.Thread(target=read_current_angle_periodically, daemon=True)
                reading_thread.start()
            else: 
                print("Connect successful. Angle reading thread may be restarting or was already active.")
                stop_reading_thread = False 
        else:
            print("Connect button: CAN connection failed.") # GUI state updated by connect_can_interface

def on_set_angle_button():
    global angle_entry 
    if not app_running: return
    if angle_entry: 
        move_motor_absolute(angle_entry.get())

def on_closing():
    global stop_reading_thread, app_running, root, reading_thread
    print("Quit initiated.")
    if not app_running: 
        print("Closing sequence already in progress."); return

    user_wants_to_quit = True
    if threading.current_thread() is threading.main_thread() and root and root.winfo_exists():
        if not messagebox.askokcancel("Quit", "Do you want to quit? CAN will be disconnected."):
            print("Quit cancelled by user."); user_wants_to_quit = False
    
    if user_wants_to_quit:
        print("Proceeding with shutdown."); app_running = False; stop_reading_thread = True
        disconnect_can_interface() 
        if root: 
            try: print("Destroying Tkinter root..."); root.destroy(); root = None; print("Tkinter root destroyed.")
            except tk.TclError as e: print(f"Tkinter TclError during destroy: {e}")
        print("Application closed.")
    else: 
        app_running = True; stop_reading_thread = False

# --- Main Application Logic ---
if __name__ == "__main__":
    app_running = True; gui_ready = False
    root = tk.Tk(); root.title(APP_TITLE)
    s = ttk.Style()
    s.configure("Emergency.TButton", foreground="white", background="red", font=('Helvetica', '10', 'bold'))
    s.configure("EstopActive.TButton", foreground="black", background="yellow", font=('Helvetica', '10', 'bold'))

    # Connection Frame
    connection_frame = ttk.LabelFrame(root, text="Connection", padding="10"); connection_frame.pack(padx=10, pady=5, fill="x")
    connect_button = ttk.Button(connection_frame, text=CONNECT_BUTTON_TEXT, command=handle_connect_button); connect_button.pack(side=tk.LEFT, padx=5)

    # Control Frame
    control_frame = ttk.LabelFrame(root, text="Motion Control", padding="10"); control_frame.pack(padx=10, pady=5, fill="x")
    
    abs_pos_frame = ttk.Frame(control_frame, padding="5"); abs_pos_frame.pack(fill="x")
    ttk.Label(abs_pos_frame, text="Target Output Angle (°):").pack(side=tk.LEFT, padx=(0,5))
    angle_entry = ttk.Entry(abs_pos_frame, width=10); angle_entry.pack(side=tk.LEFT, padx=5); angle_entry.insert(0, "0.0")
    set_angle_button = ttk.Button(abs_pos_frame, text="Set Angle", command=on_set_angle_button); set_angle_button.pack(side=tk.LEFT, padx=5)

    params_frame = ttk.Frame(control_frame, padding="5"); params_frame.pack(fill="x", pady=5)
    ttk.Label(params_frame, text="Speed (0-1000):").pack(side=tk.LEFT, padx=(0,2)) 
    speed_scale = ttk.Scale(params_frame, from_=MIN_SPEED, to=MAX_SPEED, orient=tk.HORIZONTAL, command=update_speed_label)
    speed_scale.set(DEFAULT_SPEED)
    speed_scale.pack(side=tk.LEFT, padx=(0,2), expand=True, fill="x")
    speed_value_label = ttk.Label(params_frame, text=f"{DEFAULT_SPEED}", width=4); speed_value_label.pack(side=tk.LEFT, padx=(0,10))
    
    ttk.Label(params_frame, text="Accel (0-255):").pack(side=tk.LEFT, padx=(0,2)) 
    accel_scale = ttk.Scale(params_frame, from_=MIN_ACCELERATION, to=MAX_ACCELERATION, orient=tk.HORIZONTAL, command=update_accel_label)
    accel_scale.set(DEFAULT_ACCELERATION)
    accel_scale.pack(side=tk.LEFT, padx=(0,2), expand=True, fill="x")
    accel_value_label = ttk.Label(params_frame, text=f"{DEFAULT_ACCELERATION}", width=3); accel_value_label.pack(side=tk.LEFT, padx=(0,5))

    # System Controls Frame
    system_ctrl_frame = ttk.LabelFrame(root, text="System & Setup", padding="10"); system_ctrl_frame.pack(padx=10, pady=5, fill="x")
    
    subdivision_outer_frame = ttk.Frame(system_ctrl_frame, padding="2") 
    subdivision_outer_frame.pack(fill="x", pady=(0,5))

    subdivision_select_frame = ttk.Frame(subdivision_outer_frame) 
    subdivision_select_frame.pack(side=tk.LEFT, padx=(0,10)) 

    ttk.Label(subdivision_select_frame, text="Motor Subdivision:").pack(side=tk.LEFT, padx=(0,5))
    subdivision_var = tk.StringVar(value=DEFAULT_SUBDIVISION_NAME) 
    subdivision_combobox = ttk.Combobox(subdivision_select_frame, textvariable=subdivision_var, 
                                        values=list(SUBDIVISION_SETTINGS.keys()), width=15, state="readonly")
    subdivision_combobox.pack(side=tk.LEFT, padx=5)
    set_subdivision_button = ttk.Button(subdivision_select_frame, text="Set Subdivision", command=on_set_subdivision_button)
    set_subdivision_button.pack(side=tk.LEFT, padx=5)

    subdivision_interpolation_var = tk.IntVar(value=1) # Default to interpolation enabled
    enable_interpolation_button = ttk.Checkbutton(subdivision_outer_frame, text="Enable Interpolation", 
                                                 variable=subdivision_interpolation_var,
                                                 command=on_toggle_subdivision_interpolation)
    enable_interpolation_button.pack(side=tk.LEFT, padx=10)


    set_zero_button = ttk.Button(system_ctrl_frame, text="Set Current as Zero", command=on_set_zero_button); set_zero_button.pack(side=tk.LEFT, padx=10, pady=(5,0))
    estop_button = ttk.Button(system_ctrl_frame, text="E-STOP", command=on_emergency_stop_button, style="Emergency.TButton"); estop_button.pack(side=tk.LEFT, padx=10, pady=(5,0))

    # Display Frame
    display_frame = ttk.LabelFrame(root, text="Status Feedback", padding="10"); display_frame.pack(padx=10, pady=5, fill="x")
    current_angle_label = ttk.Label(display_frame, text=STATUS_DEFAULT_TEXT, font=('Helvetica', '10', 'bold')); current_angle_label.pack(side=tk.LEFT, padx=5)
    
    status_bar_label = ttk.Label(root, text="Not Connected.", relief=tk.SUNKEN, anchor=tk.W, padding="2"); status_bar_label.pack(side=tk.BOTTOM, fill="x", pady=(5,0), padx=0)

    update_gui_for_connection_status(connected=False)
    gui_ready = True
    root.protocol("WM_DELETE_WINDOW", on_closing)

    try: print("Starting Tkinter mainloop..."); root.mainloop()
    except KeyboardInterrupt: print("Keyboard interrupt by user.")
    except tk.TclError as e: 
        if "application has been destroyed" in str(e).lower(): print("Tkinter TclError on exit (expected).")
        else: print(f"Unexpected Tkinter TclError: {e}"); traceback.print_exc()
    finally:
        print("Mainloop exited or exception. Final cleanup...")
        if app_running: on_closing()
        if reading_thread and reading_thread.is_alive():
            print("Main finally: Reading thread still alive. Attempting final join."); stop_reading_thread = True
            reading_thread.join(timeout=1.0)
            if reading_thread.is_alive(): print("Warning: Reading thread did not join in main finally.")
        print("Application terminated.")
