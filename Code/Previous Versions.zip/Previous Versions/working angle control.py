import tkinter as tk
from tkinter import ttk, messagebox
import can
# Ensure this points to the correct package location
from mks_servo_can import MksServo 
import threading
import time
import struct 
import traceback 

# --- Configuration ---
CAN_INTERFACE = "socketcan" 
CAN_CHANNEL = "can0"        
CAN_BITRATE = 500000
SERVO_CAN_ID = 1            # Your Servo's Node ID
GEAR_RATIO = 17.0

# Base CAN IDs
BASE_CONFIG_CAN_ID = 0x140 
BASE_FEEDBACK_CAN_ID = 0x240 

# Command byte for reading encoder (used by MksCustomListener to identify the response type)
CMD_READ_ENCODER_BYTE = 0x30 

# Global variables
bus = None
notifier = None
servo_wrapper = None 
current_output_angle_deg = 0.0
stop_reading_thread = False
gui_ready = False
app_running = True 

latest_motor_angle_cdeg = None 
motor_angle_update_event = threading.Event()

feedback_can_id_to_listen = None 


class MksCustomListener(can.Listener): 
    # ... (MksCustomListener code remains the same as the previous version) ...
    def __init__(self, expected_feedback_id, expected_response_cmd_byte): 
        super().__init__()
        self.expected_feedback_id = expected_feedback_id
        self.expected_response_cmd_byte = expected_response_cmd_byte
        print(f"Custom Listener initialized. Expecting command {hex(self.expected_response_cmd_byte)} responses on CAN ID {hex(self.expected_feedback_id)}")

    def on_message_received(self, msg: can.Message):
        global latest_motor_angle_cdeg, motor_angle_update_event
        
        if msg.arbitration_id == self.expected_feedback_id:
            if msg.dlc >= 5 and msg.data[0] == self.expected_response_cmd_byte: 
                try:
                    # Assumes bytes 1-4 = angle value (int32, little-endian) in centi-degrees. VERIFY!
                    parsed_value_cdeg = struct.unpack('<i', msg.data[1:5])[0]
                    latest_motor_angle_cdeg = parsed_value_cdeg
                    motor_angle_update_event.set() 
                except struct.error as e:
                    print(f"CustomListener: Error unpacking 0x30 response data: {e}, data: {msg.data.hex()}")
                except Exception as e:
                    print(f"CustomListener: Error processing 0x30 response: {e}, data: {msg.data.hex()}")


def connect_can():
    # ... (connect_can code remains the same as the previous version) ...
    global bus, notifier, servo_wrapper, app_running
    global feedback_can_id_to_listen 

    if not app_running: return False

    feedback_can_id_to_listen = BASE_FEEDBACK_CAN_ID + SERVO_CAN_ID 

    try:
        bus = can.interface.Bus(interface=CAN_INTERFACE, channel=CAN_CHANNEL, bitrate=CAN_BITRATE)
        if bus is None:
            raise ConnectionError("Failed to initialize CAN bus, bus object is None.")
        
        initial_listeners = []
        notifier = can.Notifier(bus, initial_listeners) 
        
        servo_wrapper = MksServo(bus, notifier, SERVO_CAN_ID) 

        print(f"--- Debug: servo_wrapper Info ---")
        print(f"Type: {type(servo_wrapper)}")
        actual_dir_output = dir(servo_wrapper)
        # print(f"Attributes (dir): {actual_dir_output}") # Keep commented unless needed for debug
        if hasattr(servo_wrapper, 'can_id'): 
            print(f"servo_wrapper has 'can_id' attribute: {servo_wrapper.can_id}")
        else:
            print("Warning: servo_wrapper does NOT have 'can_id' attribute.")
        print(f"--- End Debug ---")

        custom_listener = MksCustomListener(feedback_can_id_to_listen, CMD_READ_ENCODER_BYTE) 
        notifier.add_listener(custom_listener)
        
        print(f"Successfully connected. Using Node ID: {SERVO_CAN_ID}. "
              f"Library methods will use internal CAN ID for commands. "
              f"Custom Listener expecting Servo->Host FBs for angle on {hex(feedback_can_id_to_listen)})")
        
        listener_names = []
        if notifier and notifier.listeners:
            for listener_obj in notifier.listeners:
                listener_names.append(str(type(listener_obj).__name__))
        print(f"Notifier listeners: {listener_names}") 
        
        # SR_Close Mode Setup (if needed)
        # ... (commented out code for set_work_mode) ...

        return True
    
    except Exception as e: 
        error_msg = f"An unexpected error occurred during CAN connection: {e}"
        print(error_msg)
        traceback.print_exc() 
        messagebox.showerror("CAN Connection Error", f"{error_msg}\nCheck console for detailed traceback.")
        bus, notifier, servo_wrapper = None, None, None
        return False


def disconnect_can():
    # ... (disconnect_can code remains the same as the previous version) ...
    global bus, notifier, stop_reading_thread, servo_wrapper, app_running
    was_app_running = app_running 
    app_running = False 
    stop_reading_thread = True 

    if reading_thread and reading_thread.is_alive() and threading.current_thread() != reading_thread:
        print("Waiting for angle reading thread to stop...")
        reading_thread.join(timeout=1.0) 
        if reading_thread.is_alive():
            print("Warning: Angle reading thread did not stop cleanly.")

    if notifier:
        try:
            notifier.stop(timeout=1.0) 
            print("Notifier stopped.")
        except Exception as e: 
            print(f"Error stopping notifier: {e}")
        notifier = None 
    if bus:
        try:
            bus.shutdown()
            print("CAN bus shutdown.")
        except Exception as e:
            print(f"Error shutting down bus: {e}")
        bus = None 
    
    servo_wrapper = None 
    print("CAN resources released.")
    if not was_app_running: 
        app_running = False


def set_output_angle(target_output_angle_deg_str):
    # ... (set_output_angle code remains the same, using positional args) ...
    global servo_wrapper
    if servo_wrapper is None: 
        messagebox.showerror("Error", "Servo not connected.")
        return

    try:
        target_output_angle_deg = float(target_output_angle_deg_str)
        motor_target_angle_deg = target_output_angle_deg * GEAR_RATIO
        
        # Assuming 'angle' for run_motor_absolute_motion_by_axis is centi-degrees. VERIFY!
        motor_target_angle_cdeg = int(motor_target_angle_deg * 100)
        
        # Use appropriate speed/acceleration values for your setup (units verified via docs)
        target_speed = 2000      # Example: Assumed RPM (0-3000 based on your can_motor.py)
        target_acceleration = 255 # Example: Unit 0-255.

        if not (-8388608 <= motor_target_angle_cdeg <= 8388607):
             messagebox.showerror("Input Error", f"Target motor angle ({motor_target_angle_cdeg} [assumed cdeg]) exceeds servo's axis limits.")
             return

        print(f"Requesting output angle: {target_output_angle_deg:.2f}° "
              f"(Motor angle target: {motor_target_angle_deg:.2f}°)\n"
              f"  Calling method with params: "
              f"speed={target_speed} [assumed RPM], " 
              f"acceleration={target_acceleration} [0-255], "
              f"absolute_axis={motor_target_angle_cdeg} [assumed cdeg]")
        
        # Call with 3 POSITIONAL arguments: (speed, acceleration, absolute_axis)
        servo_wrapper.run_motor_absolute_motion_by_axis(target_speed, 
                                                        target_acceleration,
                                                        motor_target_angle_cdeg) 
        
        print(f"Command 'run_motor_absolute_motion_by_axis' sent.")

    except ValueError:
        messagebox.showerror("Input Error", "Invalid angle format. Please enter a number.")
    except AttributeError as e: 
        messagebox.showerror("Library Error", f"MksServo method error: {e}. Is method name correct?")
        traceback.print_exc()
    except TypeError as te: 
        messagebox.showerror("Library Error", f"MksServo method argument error: {te}. Check parameters.")
        traceback.print_exc()
    except Exception as e: 
        messagebox.showerror("Servo Command Error", f"Error commanding servo: {e}")
        traceback.print_exc()


def read_current_angle_periodically():
    # ... (read_current_angle_periodically code remains the same) ...
    global current_output_angle_deg, servo_wrapper, stop_reading_thread, gui_ready, app_running
    global latest_motor_angle_cdeg, motor_angle_update_event

    print("Angle reading thread started.")
    attr_error_traceback_printed = False 

    while not stop_reading_thread and app_running:
        if servo_wrapper and gui_ready and bus: 
            try:
                servo_wrapper.read_encoder_value_addition() 
                
                motor_angle_update_event.clear() 
                if motor_angle_update_event.wait(timeout=0.2): 
                    if latest_motor_angle_cdeg is not None:
                        # Assumes latest_motor_angle_cdeg unit is centi-degrees (0.01 deg) - VERIFY!
                        current_motor_angle_mdeg = latest_motor_angle_cdeg * 10 
                        current_motor_angle_deg = current_motor_angle_mdeg / 1000.0 
                        current_output_angle_deg = current_motor_angle_deg / GEAR_RATIO
                        
                        if app_running: 
                            root.after(0, update_angle_display, current_output_angle_deg)
                # else: 
                    # print("Timeout waiting for motor angle update from listener.")
                    # pass
            
            except AttributeError as e: 
                if app_running and not stop_reading_thread:
                    print(f"Attribute error in reading thread (method call): {e}.")
                    # if not attr_error_traceback_printed:
                    #     traceback.print_exc()
                    #     attr_error_traceback_printed = True
                time.sleep(0.2) 
            except Exception as e:
                if app_running and not stop_reading_thread:
                    print(f"Error in angle reading thread: {e}")
                time.sleep(0.1) 
        else:
            if stop_reading_thread or not app_running:
                break 
        time.sleep(0.1) 
    print("Angle reading thread stopped.")

# --- NEW FUNCTION for Setting Zero ---
def on_set_zero_button():
    """Calls the library function to set the current motor position as zero."""
    global servo_wrapper
    if servo_wrapper is None:
        messagebox.showerror("Error", "Servo not connected.")
        return

    print("Attempting to set current position as zero...")
    try:
        # Based on dir() output, 'set_current_axis_to_zero' seems the correct method.
        # This method likely takes no arguments other than self.
        servo_wrapper.set_current_axis_to_zero()
        print("Command 'set_current_axis_to_zero' sent successfully.")
        messagebox.showinfo("Set Zero", "Command sent to set current position as zero.")
        # Force an immediate angle update request after setting zero
        if reading_thread and reading_thread.is_alive():
            print("Requesting immediate angle update after setting zero.")
            servo_wrapper.read_encoder_value_addition()
            
    except AttributeError:
        messagebox.showerror("Library Error", "The method 'set_current_axis_to_zero' was not found in the MksServo object. Your library version might differ.")
        print("AttributeError: set_current_axis_to_zero not found.")
        traceback.print_exc()
    except Exception as e:
        messagebox.showerror("Servo Command Error", f"Error sending 'set zero' command: {e}")
        print(f"Error in on_set_zero_button: {e}")
        traceback.print_exc()

# --- GUI Functions (remain the same) ---
def update_angle_display(angle_deg):
    if app_running and current_angle_label: 
        current_angle_label.config(text=f"Current Output Angle: {angle_deg:.2f}°")

def on_set_angle_button():
    if not app_running: return
    desired_angle_str = angle_entry.get()
    set_output_angle(desired_angle_str)

def on_closing():
    # ... (on_closing code remains the same) ...
    global stop_reading_thread, app_running 
    
    if messagebox.askokcancel("Quit", "Do you want to quit? This will attempt to stop the motor and disconnect CAN."):
        print("Quit initiated by user.")
        disconnect_can() 
        
        if root:
            try:
                root.destroy() 
            except tk.TclError: 
                pass
        print("Application closed.")


# --- GUI Setup ---
root = tk.Tk()
root.title("Rotation Stage Control")

# Frame for connection
# ... (connection_frame code remains the same) ...
connection_frame = ttk.LabelFrame(root, text="Connection", padding="10")
connection_frame.pack(padx=10, pady=10, fill="x")
connect_button = ttk.Button(connection_frame, text="Connect to CAN & Servo", command=connect_can)
connect_button.pack(side=tk.LEFT, padx=5)

# Frame for control - ADDING SET ZERO BUTTON HERE
# ... (control_frame code updated) ...
control_frame = ttk.LabelFrame(root, text="Control", padding="10")
control_frame.pack(padx=10, pady=10, fill="x")

ttk.Label(control_frame, text="Desired Output Angle (°):").pack(side=tk.LEFT, padx=5)
angle_entry = ttk.Entry(control_frame, width=10)
angle_entry.pack(side=tk.LEFT, padx=5)
angle_entry.insert(0, "0.0") 
set_button = ttk.Button(control_frame, text="Set Angle", command=on_set_angle_button)
set_button.pack(side=tk.LEFT, padx=5)

# Add the new "Set Zero" button
set_zero_button = ttk.Button(control_frame, text="Set Current as Zero", command=on_set_zero_button)
set_zero_button.pack(side=tk.LEFT, padx=10) # Added more padding

# Frame for display
# ... (display_frame code remains the same) ...
display_frame = ttk.LabelFrame(root, text="Status", padding="10")
display_frame.pack(padx=10, pady=5, fill="x") 
current_angle_label = ttk.Label(display_frame, text="Current Output Angle: N/A")
current_angle_label.pack(side=tk.LEFT, padx=5)

# --- Main Application Logic (remains the same) ---
reading_thread = None

if __name__ == "__main__":
    if connect_can(): 
        stop_reading_thread = False 
        app_running = True    
        reading_thread = threading.Thread(target=read_current_angle_periodically, daemon=True)
        reading_thread.start()
        gui_ready = True 
    else:
        app_running = True 
        gui_ready = False 
        messagebox.showwarning("Startup Warning", "Could not connect to CAN bus on startup. Please check connections/setup and use the 'Connect' button.")
        
    root.protocol("WM_DELETE_WINDOW", on_closing) 
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("Keyboard interrupt received. Closing application.")
        if app_running: 
             on_closing() 
    finally:
        if app_running: 
            print("Mainloop exited. Performing cleanup...")
            on_closing() 
        print("Application terminated.")