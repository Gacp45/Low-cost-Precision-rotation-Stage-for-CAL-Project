import tkinter as tk
from tkinter import ttk, messagebox
import can
from mks_servo_can import MksServo 
import threading
import time
# import struct # No longer needed
import traceback

CAN_INTERFACE = "socketcan"
CAN_CHANNEL = "can0"
CAN_BITRATE = 500000
SERVO_CAN_ID = 1
GEAR_RATIO = 17.0 

# PULSES_PER_MOTOR_DEGREE is NO LONGER USED as library provides centi-degrees.
print("Using MKS library's 'read_encoder_value_addition()' for feedback (expected motor cdeg).")

bus = None
notifier = None
servo_wrapper = None
current_output_angle_deg = 0.0 
stop_reading_thread = False
gui_ready = False
app_running = True
e_stop_active = False

# This will store the offset from the library's feedback value (in motor centi-degrees)
# It's the absolute cdeg value reported by the servo when "Set Zero" was last pressed.
library_motor_offset_cdeg = 0 

# No custom listener needed
# custom_listener_instance = None 

def connect_can():
    global bus, notifier, servo_wrapper, app_running, e_stop_active, library_motor_offset_cdeg
    if not app_running: return False
    e_stop_active = False
    library_motor_offset_cdeg = 0 
    print("Attempting connection...")
    try:
        bus = can.interface.Bus(interface=CAN_INTERFACE, channel=CAN_CHANNEL, bitrate=CAN_BITRATE)
        if bus is None: raise ConnectionError("CAN bus is None.")
        
        initial_listeners = [] 
        notifier = can.Notifier(bus, initial_listeners) 
        servo_wrapper = MksServo(bus, notifier, SERVO_CAN_ID) 

        if hasattr(servo_wrapper, 'can_id'): print(f"servo_wrapper.can_id: {servo_wrapper.can_id}")
        else: print("Warning: servo_wrapper no 'can_id' attribute.")
        print(f"Connected. Servo Node ID: {SERVO_CAN_ID}.")
        listener_names = [str(type(l).__name__) for l in notifier.listeners if notifier and notifier.listeners]
        print(f"Notifier listeners: {listener_names}") 
        
        if servo_wrapper:
            print("Attempting initial angle read from library...")
            try:
                # This is the key working method from the MKS example
                initial_cdeg = servo_wrapper.read_encoder_value_addition() 
                print(f"  Initial call to read_encoder_value_addition() returned: {initial_cdeg} (type: {type(initial_cdeg)})")
                if isinstance(initial_cdeg, int):
                    library_motor_offset_cdeg = initial_cdeg 
                    print(f"  Initial library_motor_offset_cdeg set to: {library_motor_offset_cdeg} (motor cdeg). Displayed angle will be relative to this until 'Set Zero'.")
                elif initial_cdeg is None:
                    print("  read_encoder_value_addition() returned None initially. Offset remains 0.")
                else:
                    print(f"  WARNING: read_encoder_value_addition() returned unexpected type: {type(initial_cdeg)}. Angle display may be incorrect.")
            except TypeError as te: # Should not happen if this method is correct
                print(f"  CRITICAL ERROR during connect: TypeError calling read_encoder_value_addition(): {te}")
                if gui_ready: messagebox.showerror("Library Error", f"Feedback method error: {te}")
            except Exception as e:
                print(f"  Error calling read_encoder_value_addition() during connect: {e}")
                if gui_ready: messagebox.showerror("Library Error", f"Feedback method error: {e}")
        return True
    except Exception as e:
        error_msg = f"CAN connection error: {e}"; print(error_msg); traceback.print_exc()
        if gui_ready: messagebox.showerror("CAN Connection Error", f"{error_msg}\nCheck console.")
        bus, notifier, servo_wrapper = None, None, None
        return False

def disconnect_can():
    global bus, notifier, stop_reading_thread, servo_wrapper, reading_thread
    print("Disconnect_can called.")
    if reading_thread and reading_thread.is_alive() and threading.current_thread() != reading_thread:
        print("Waiting for angle reading thread to stop...")
        reading_thread.join(timeout=2.0) 
        if reading_thread.is_alive(): print("Warning: Angle reading thread did not stop cleanly.")
        else: print("Angle reading thread stopped.")
    if notifier:
        try: notifier.stop(timeout=1.0); print("Notifier stopped.")
        except Exception as e: print(f"Error stopping notifier: {e}")
        notifier = None
    if bus:
        try: bus.shutdown(); print("CAN bus shutdown.")
        except Exception as e: print(f"Error shutting bus: {e}")
        bus = None
    servo_wrapper = None; print("CAN resources released.")

def set_output_angle(target_output_angle_deg_str):
    global servo_wrapper, e_stop_active
    if e_stop_active: messagebox.showwarning("E-STOP Active", "Motion blocked."); return
    if servo_wrapper is None: messagebox.showerror("Error", "Servo not connected."); return
    try:
        target_output_angle_deg = float(target_output_angle_deg_str)
        motor_target_angle_deg = target_output_angle_deg * GEAR_RATIO
        motor_target_angle_cdeg = int(motor_target_angle_deg * 100)
        
        target_speed = 1000 # Restored to a more practical speed
        # target_speed = 50 # If you still want slow for testing
        target_acceleration = 255

        if not (-8388608 <= motor_target_angle_cdeg <= 8388607): 
             messagebox.showerror("Input Error", f"Target motor angle ({motor_target_angle_cdeg} [cdeg]) exceeds limits."); return
        print(f"Requesting output: {target_output_angle_deg:.2f}° (Motor: {motor_target_angle_deg:.2f}° => {motor_target_angle_cdeg} cdeg)\n"
              f"  Params: speed={target_speed}, accel={target_acceleration}, abs_axis={motor_target_angle_cdeg} cdeg")
        servo_wrapper.run_motor_absolute_motion_by_axis(target_speed, target_acceleration, motor_target_angle_cdeg)
        print(f"Command 'run_motor_absolute_motion_by_axis' sent (cdeg).")
    except ValueError: messagebox.showerror("Input Error", "Invalid angle format.")
    except Exception as e: messagebox.showerror("Servo Command Error", f"Error: {e}"); traceback.print_exc()

def read_current_angle_periodically():
    global current_output_angle_deg, servo_wrapper, stop_reading_thread, app_running, gui_ready, e_stop_active
    global library_motor_offset_cdeg

    print("Angle reading thread started (Using MKS library: read_encoder_value_addition()).")
    loop_count, log_interval = 0, 20 # Log every ~2 seconds if loop is 0.1s total
    query_frequency = 1 # Query every loop pass for ~10Hz feedback rate

    while not stop_reading_thread and app_running:
        if gui_ready:
            loop_count += 1
            calculated_out_angle = None 
            raw_cdeg_from_lib = None

            if servo_wrapper and not e_stop_active and loop_count % query_frequency == 0:
                try:
                    raw_cdeg_from_lib = servo_wrapper.read_encoder_value_addition() 
                    
                    if raw_cdeg_from_lib is not None:
                        if isinstance(raw_cdeg_from_lib, int):
                            relative_motor_cdeg = raw_cdeg_from_lib - library_motor_offset_cdeg 
                            motor_angle_deg = relative_motor_cdeg / 100.0
                            calculated_out_angle = motor_angle_deg / GEAR_RATIO
                            current_output_angle_deg = calculated_out_angle
                        else: # Should not happen if library is consistent
                            if loop_count % log_interval == 0: 
                                print(f"Warning: read_encoder_value_addition() returned non-integer: {raw_cdeg_from_lib} (type: {type(raw_cdeg_from_lib)})")
                            calculated_out_angle = None 
                except TypeError as te: 
                    if loop_count % (log_interval * 5) == 0: # Log critical error less frequently
                        print(f"CRITICAL Reader: TypeError from read_encoder_value_addition(): {te}. Feedback stopped.")
                    # No point in continuing if the method is broken. Or, could let it run and just show N/A.
                    # For now, just log and it will show N/A.
                    pass # Allow loop to continue, but feedback will be None
                except Exception as e: 
                    if loop_count % log_interval == 0: print(f"Error in reader query: {e}")
            
            if loop_count % log_interval == 0:
                print(f"AngleCalc (L{loop_count}): RawLib_cdeg={raw_cdeg_from_lib}, LibOffset_cdeg={library_motor_offset_cdeg}, OutputAngle={calculated_out_angle if calculated_out_angle is not None else 'N/A'}")

            if calculated_out_angle is not None and app_running and root and root.winfo_exists():
                try: root.after(0, update_angle_display, calculated_out_angle)
                except tk.TclError:
                    if app_running: print("AngleRead: root.after failed, window closing.")
                    break 
        else: 
            if stop_reading_thread or not app_running: break
            time.sleep(0.1)
        time.sleep(0.1) # Main loop poll interval
    print("Angle reading thread stopped.")

def on_set_zero_button():
    global servo_wrapper, current_output_angle_deg, app_running, root, e_stop_active
    global library_motor_offset_cdeg 

    if e_stop_active: 
        if app_running and root and root.winfo_exists(): messagebox.showwarning("E-STOP Active", "Cannot set zero.")
        else: print("E-STOP Active, cannot set zero.")
        return
    if servo_wrapper is None: 
        if app_running and root and root.winfo_exists(): messagebox.showerror("Error", "Servo not connected.")
        else: print("Error: Servo not connected for Set Zero.")
        return
    
    print("Attempting to set current position as zero...")
    try:
        servo_wrapper.set_current_axis_to_zero() 
        print("Command 'set_current_axis_to_zero' sent to servo controller.")
        time.sleep(0.1) # Give servo a moment to process
        
        # Capture the current absolute cdeg value from the library to be the new offset
        current_cdeg_at_zero = None
        try:
            current_cdeg_at_zero = servo_wrapper.read_encoder_value_addition()
        except TypeError as te:
            print(f"CRITICAL SetZero: TypeError calling read_encoder_value_addition(): {te}. Cannot update offset.")
            if app_running and root and root.winfo_exists():
                messagebox.showerror("Library Error", f"Cannot capture zero offset due to library error: {te}")
            return 
        except Exception as e_capture:
            print(f"SetZero: Error capturing offset value via read_encoder_value_addition(): {e_capture}")
            # Optionally, show an error to the user if capture fails
            if app_running and root and root.winfo_exists():
                messagebox.showwarning("Set Zero", f"Failed to read encoder value for new offset: {e_capture}")
            # Decide if we should proceed or return
            # For now, if capture fails, we keep the old offset.
            # Or we could try a few times. For simplicity now:
            current_cdeg_at_zero = None # Ensure it's None if error


        if current_cdeg_at_zero is not None and isinstance(current_cdeg_at_zero, int):
            library_motor_offset_cdeg = current_cdeg_at_zero 
            print(f"New display zero offset captured: {library_motor_offset_cdeg} (motor cdeg from library)")
        else:
            print(f"Warning: Could not get valid value from library to set new zero offset (got: {current_cdeg_at_zero}). Offset remains: {library_motor_offset_cdeg}")

        current_output_angle_deg = 0.0 
        if app_running and root and root.winfo_exists(): 
            update_angle_display(current_output_angle_deg)
            messagebox.showinfo("Set Zero", "Motor internal zero reset. Display offset updated.")
        elif app_running: print("Set Zero: GUI not available for confirmation.")

    except Exception as e: 
        if app_running and root and root.winfo_exists(): messagebox.showerror("Servo Command Error", f"Error during 'set zero': {e}")
        else: print(f"Error during 'set zero' (GUI unavailable): {e}")
        traceback.print_exc()

def on_emergency_stop_button():
    # ... (same as V5.2) ...
    global servo_wrapper, e_stop_active
    if servo_wrapper is None: messagebox.showerror("Error", "Servo not connected."); return
    print("Sending EMERGENCY STOP command...")
    try:
        result = servo_wrapper.emergency_stop_motor()
        print(f"E-Stop cmd sent. Lib Result: {result}") 
        e_stop_active = True
        if app_running and root and root.winfo_exists(): 
            messagebox.showinfo("E-STOP", f"E-Stop cmd sent (Lib Result: {result}). Motion blocked. NOTE: Library previously reported command failure - E-Stop may not be effective.")
        else: print("E-STOP: GUI not available for confirmation.")
    except AttributeError: 
        err_msg = "Library Error: No 'emergency_stop_motor' method."
        if app_running and root and root.winfo_exists(): messagebox.showerror("Library Error", err_msg)
        else: print(err_msg)
        traceback.print_exc()
    except Exception as e: 
        err_msg_detail = f"E-STOP Error: {e}"
        if app_running and root and root.winfo_exists(): messagebox.showerror("Servo Command Error", err_msg_detail)
        else: print(f"{err_msg_detail} (GUI unavailable)")
        traceback.print_exc()

def update_angle_display(angle_deg):
    # ... (same as V5.2) ...
    if app_running and current_angle_label and root and root.winfo_exists():
        new_text = f"Current Output Angle: {angle_deg:.3f}°" 
        if not hasattr(update_angle_display, 'last_gui_text') or update_angle_display.last_gui_text != new_text:
            update_angle_display.last_gui_text = new_text
        try: current_angle_label.config(text=new_text)
        except tk.TclError:
             if app_running : print("Update_angle_display: Label error, window closing.")

def on_set_angle_button():
    # ... (same as V5.2) ...
    if not app_running: return
    set_output_angle(angle_entry.get())

def on_closing():
    # ... (same as V5.2) ...
    global stop_reading_thread, app_running, root, reading_thread
    print("Quit initiated.")
    if not app_running: print("Closing already started."); return
    
    user_wants_to_quit = True 
    if threading.current_thread() is threading.main_thread() and root and root.winfo_exists():
         if not messagebox.askokcancel("Quit", "Do you want to quit? This will disconnect CAN."):
            print("Quit cancelled by user."); user_wants_to_quit = False
            
    if user_wants_to_quit:
        print("Proceeding with shutdown.")
        app_running = False      
        stop_reading_thread = True 
        
        print("Signaled reading thread to stop. Calling disconnect_can...")
        disconnect_can() 
        
        if root: 
            try: 
                print("Destroying Tkinter root window...")
                root.destroy(); root = None
                print("Tkinter root destroyed.")
            except tk.TclError as e: print(f"Tkinter TclError during destroy: {e}")
        print("Application closed.")

# --- GUI Setup ---
# ... (same as V5.2, title updated) ...
root = tk.Tk(); root.title("Rotation Stage Control (Library Feedback)")
connection_frame = ttk.LabelFrame(root, text="Connection", padding="10"); connection_frame.pack(padx=10, pady=10, fill="x", expand=False)
connect_button = ttk.Button(connection_frame, text="Connect", command=connect_can); connect_button.pack(side=tk.LEFT, padx=5)
control_frame = ttk.LabelFrame(root, text="Control", padding="10"); control_frame.pack(padx=10, pady=10, fill="x", expand=False)
ttk.Label(control_frame, text="Output Angle (°):").pack(side=tk.LEFT, padx=5)
angle_entry = ttk.Entry(control_frame, width=10); angle_entry.pack(side=tk.LEFT, padx=5); angle_entry.insert(0, "0.0")
set_button = ttk.Button(control_frame, text="Set Angle", command=on_set_angle_button); set_button.pack(side=tk.LEFT, padx=5)
set_zero_button = ttk.Button(control_frame, text="Set Zero", command=on_set_zero_button); set_zero_button.pack(side=tk.LEFT, padx=10)
estop_button = ttk.Button(control_frame, text="E-STOP", command=on_emergency_stop_button, style="Emergency.TButton"); estop_button.pack(side=tk.LEFT, padx=10)
s = ttk.Style(); s.configure("Emergency.TButton", foreground="white", background="red", font=('Helvetica', '10', 'bold'))
display_frame = ttk.LabelFrame(root, text="Status", padding="10"); display_frame.pack(padx=10, pady=5, fill="x", expand=False)
current_angle_label = ttk.Label(display_frame, text="Current Output Angle: N/A"); current_angle_label.pack(side=tk.LEFT, padx=5)

# --- Main Application Logic ---
# ... (same as V5.2) ...
reading_thread = None
if __name__ == "__main__":
    app_running, gui_ready = True, False
    if connect_can(): 
        stop_reading_thread = False
        reading_thread = threading.Thread(target=read_current_angle_periodically, daemon=True); reading_thread.start()
    else: 
        if root and root.winfo_exists(): 
             messagebox.showwarning("Startup Warning", "Could not connect CAN. Check setup & 'Connect' button.")
        else:
            print("Startup Warning: Could not connect CAN. GUI not available for messagebox.")

    if root: 
        gui_ready = True
        root.protocol("WM_DELETE_WINDOW", on_closing)
        try: 
            print("Starting Tkinter mainloop..."); 
            root.mainloop()
        except KeyboardInterrupt: 
            print("Keyboard interrupt received.")
        except tk.TclError as e:
            if "application has been destroyed" in str(e).lower(): print("Tkinter mainloop TclError on exit (expected).")
            else: print(f"Unexpected Tkinter TclError: {e}"); traceback.print_exc()
        finally:
            print("Mainloop exited or exception. Performing final cleanup...")
            if app_running: 
                on_closing()
            else: 
                if reading_thread and reading_thread.is_alive():
                    print("Main finally: Reading thread still alive after on_closing, attempting join...")
                    stop_reading_thread = True 
                    reading_thread.join(timeout=1.0)
                    if reading_thread.is_alive(): print("Warning: Reading thread did not join in main finally.")
            print("Application terminated.")
    else:
        print("CRITICAL: Tkinter root window not initialized. Application cannot start GUI.")
        app_running = False; stop_reading_thread = True
        if reading_thread and reading_thread.is_alive(): reading_thread.join(timeout=0.5)
        print("Application terminated without GUI.")