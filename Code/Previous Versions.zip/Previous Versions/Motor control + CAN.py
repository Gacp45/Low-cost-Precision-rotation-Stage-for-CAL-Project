import tkinter as tk
import RPi.GPIO as GPIO
import time
import can
import struct

# GPIO Setup
DIR_PIN = 22
STEP_PIN = 18
EN_PIN = 17

GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR_PIN, GPIO.OUT)
GPIO.setup(STEP_PIN, GPIO.OUT)
GPIO.setup(EN_PIN, GPIO.OUT)
GPIO.output(EN_PIN, GPIO.LOW)  # Enable motor

# CAN Setup
can_interface = 'can0'
bus = can.interface.Bus(channel=can_interface, bustype='socketcan')
node_id = 1  # Default for SERVO42D

def send_step(direction, steps=200, delay=0.001):
    GPIO.output(DIR_PIN, GPIO.HIGH if direction == 'right' else GPIO.LOW)
    for _ in range(steps):
        GPIO.output(STEP_PIN, GPIO.HIGH)
        time.sleep(delay)
        GPIO.output(STEP_PIN, GPIO.LOW)
        time.sleep(delay)

def read_position():
    can_id = 0x600 + node_id
    data = [0x40, 0x64, 0x60, 0x00, 0, 0, 0, 0]  # SDO read for 0x6064
    msg = can.Message(arbitration_id=can_id, data=data, is_extended_id=False)
    try:
        bus.send(msg)
        while True:
            response = bus.recv(timeout=1.0)
            if response and response.arbitration_id == (0x580 + node_id):
                pos_bytes = response.data[4:8]
                position = struct.unpack('<i', bytes(pos_bytes))[0]
                return position
    except Exception as e:
        print(f"CAN error: {e}")
    return None

# GUI Setup
root = tk.Tk()
root.title("Motor Control GUI")

position_label = tk.Label(root, text="Position: ???", font=("Arial", 16))
position_label.pack(pady=10)

def update_position_label():
    pos = read_position()
    if pos is not None:
        position_label.config(text=f"Position: {pos}")
    else:
        position_label.config(text="Position: Error")
    root.after(500, update_position_label)

def move_left():
    send_step('left')

def move_right():
    send_step('right')

btn_left = tk.Button(root, text="Move Left", command=move_left, width=20)
btn_left.pack(pady=5)

btn_right = tk.Button(root, text="Move Right", command=move_right, width=20)
btn_right.pack(pady=5)

# Start updating position
update_position_label()

try:
    root.mainloop()
finally:
    GPIO.cleanup()
